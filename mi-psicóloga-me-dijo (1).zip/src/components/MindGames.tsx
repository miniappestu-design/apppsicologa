import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, Heart, Sparkles, Smile, RefreshCw, Star, Trash2, Shield, 
  Wind, ArrowUp, ArrowDown, HelpCircle, AlertCircle, Compass, 
  Dribbble, Sun, Trophy 
} from 'lucide-react';
import { Language, UserState } from '../types';
import { audioSynth } from '../lib/audio';

interface MindGamesProps {
  language: Language;
  userState: UserState;
  onGainXP: (amount: number) => void;
  onClose: () => void;
}

interface GameDefinition {
  id: string;
  title: string;
  description: string;
  instructions: string;
  emoji: string;
}

export default function MindGames({ language, userState, onGainXP, onClose }: MindGamesProps) {
  const currentTheme = userState.theme;
  const isEs = language === 'es' || language === 'ca';
  
  // Selection States
  const [selectedEmotion, setSelectedEmotion] = useState<string | null>(null);
  const [activeGame, setActiveGame] = useState<GameDefinition | null>(null);
  const [gameState, setGameState] = useState<any>({});
  const [showCelebration, setShowCelebration] = useState(false);
  const [earnedXP, setEarnedXP] = useState(0);

  const emotions = [
    { id: 'ansiedad', label: isEs ? 'Ansiedad' : 'Anxiety', emoji: '🌸', color: 'from-rose-400 to-rose-500' },
    { id: 'estres', label: isEs ? 'Estrés' : 'Stress', emoji: '⚡', color: 'from-amber-400 to-amber-500' },
    { id: 'tristeza', label: isEs ? 'Tristeza' : 'Sadness', emoji: '🌧️', color: 'from-blue-400 to-blue-500' },
    { id: 'autoestima', label: isEs ? 'Autoestima' : 'Self-esteem', emoji: '👑', color: 'from-purple-400 to-purple-500' },
    { id: 'luto', label: isEs ? 'Luto' : 'Grief', emoji: '🕯️', color: 'from-indigo-400 to-indigo-500' },
    { id: 'separacion', label: isEs ? 'Separación' : 'Separation', emoji: '💔', color: 'from-coral-400 to-coral-500' },
    { id: 'miedo', label: isEs ? 'Miedo' : 'Fear', emoji: '👁️', color: 'from-teal-400 to-teal-500' },
    { id: 'culpa', label: isEs ? 'Culpa' : 'Guilt', emoji: '🪨', color: 'from-emerald-400 to-emerald-500' }
  ];

  const gamesByEmotion: Record<string, GameDefinition[]> = {
    ansiedad: [
      { id: 'breathe_follow', title: isEs ? 'Sigue la respiración' : 'Follow the breath', description: isEs ? 'Mantén presionado para inhalar, suelta para exhalar en sincronía con el loto floral.' : 'Hold down to inhale, release to exhale in sync with the floral lotus.', instructions: isEs ? 'Presiona y mantén presionado el botón para inhalar mientras el loto se expande. Suelta para exhalar.' : 'Press and hold the button to inhale as the lotus expands. Release to exhale.', emoji: '🌸' },
      { id: 'pop_bubbles', title: isEs ? 'Explota las burbujas' : 'Pop the stress bubbles', description: isEs ? 'Toca y explota las burbujas flotantes para liberar la presión acumulada.' : 'Tap and burst floating bubbles to release accumulated tension.', instructions: isEs ? 'Haz clic en las burbujas de colores para explotarlas y sumar puntos de tranquilidad.' : 'Click on colorful bubbles to pop them and earn peace points.', emoji: '🫧' },
      { id: 'catch_calm', title: isEs ? 'Atrapa la calma' : 'Catch the calm', description: isEs ? 'Toca los destellos de serenidad flotantes antes de que desaparezcan.' : 'Tap descending serene sparks before they fade away.', instructions: isEs ? 'Atrapa los orbes de luz rosa y dorada para llenar tu barra de paz.' : 'Catch pink and golden light orbs to fill your peace gauge.', emoji: '✨' },
      { id: 'breathe_slide', title: isEs ? 'Respiración interactiva' : 'Interactive breathing track', description: isEs ? 'Arrastra el dial hacia arriba para inhalar y hacia abajo para exhalar.' : 'Drag the slider up to inhale and down to exhale.', instructions: isEs ? 'Desliza hacia arriba para inhalar y hacia abajo para exhalar de manera fluida.' : 'Slide up to inhale and down to exhale smoothly.', emoji: '🍃' }
    ],
    estres: [
      { id: 'order_chaos', title: isEs ? 'Ordena el caos' : 'Order the chaos', description: isEs ? 'Arrastra o toca las palabras del caos para alinearlas con la serenidad.' : 'Sort scattered words of stress into peaceful slots.', instructions: isEs ? 'Coloca las palabras dispersas en orden correcto de menor a mayor tensión.' : 'Sort words of tension from highest to lowest state of peace.', emoji: '🧩' },
      { id: 'sort_thoughts', title: isEs ? 'Organiza pensamientos' : 'Filter your thoughts', description: isEs ? 'Clasifica tus pensamientos: arrastra la autocrítica a la papelera y el amor propio a tu corazón.' : 'Sort thoughts: drag self-criticism to the trash, self-love to your heart.', instructions: isEs ? 'Desliza a la izquierda para desechar lo negativo; desliza a la derecha para atesorar lo constructivo.' : 'Swipe left to discard toxic ideas, swipe right to cherish self-love.', emoji: '🧠' },
      { id: 'relaxing_puzzle', title: isEs ? 'Puzzle relajante' : 'Tranquil puzzle', description: isEs ? 'Gira y completa una escena de atardecer pacífico para reenfocar tu mente.' : 'Rotate tiles to build a beautiful serene sunset mosaic.', instructions: isEs ? 'Haz clic en cada ficha para girarla hasta armar la imagen perfecta del atardecer.' : 'Click on each tile to rotate it and reconstruct the beautiful sunset scenery.', emoji: '🌅' },
      { id: 'find_balance', title: isEs ? 'Encuentra el equilibrio' : 'Find the balance', description: isEs ? 'Mantén el dial dorado en el centro exacto compensando las oscilaciones.' : 'Keep the golden dial centered while compensating for oscillations.', instructions: isEs ? 'Usa los botones para compensar y sostener el orbe en el punto de equilibrio absoluto.' : 'Use left and right buttons to keep the orb perfectly centered on the balance beam.', emoji: '⚖️' }
    ],
    tristeza: [
      { id: 'rebuild_garden', title: isEs ? 'Reconstruye el jardín' : 'Rebuild the garden', description: isEs ? 'Siembre flores en tu jardín interno para traer color y alegría de nuevo.' : 'Plant flowers in your inner garden to bring back color and life.', instructions: isEs ? 'Toca los espacios vacíos del prado para plantar rosas y lavandas silvestres.' : 'Tap empty spaces in the meadow to plant roses and lavender flowers.', emoji: '🏡' },
      { id: 'plant_hope', title: isEs ? 'Planta esperanza' : 'Plant hope', description: isEs ? 'Escribe tu anhelo o sueño y míralo germinar en un árbol resplandeciente.' : 'Write down your hope and see it grow into a radiant golden sprout.', instructions: isEs ? 'Escribe una pequeña frase de esperanza. Presiona plantar para ver brotar tu árbol.' : 'Type a small hopeful dream and press plant to see your tree blossom.', emoji: '🌱' },
      { id: 'light_sky', title: isEs ? 'Ilumina el cielo' : 'Light up the night', description: isEs ? 'Toca las estrellas apagadas para iluminar el cielo de tu alma.' : 'Tap dark constellation points to illuminate your sky with constellations.', instructions: isEs ? 'Enciende todas las estrellas grises para iluminar la galaxia con música.' : 'Tap each dark sky coordinate to light up stars and reveal constellations.', emoji: '🌌' }
    ],
    autoestima: [
      { id: 'complete_affirmations', title: isEs ? 'Completa afirmaciones' : 'Self-affirmations builder', description: isEs ? 'Une palabras empoderadoras para formular tus verdades internas diarias.' : 'Drag empowering words to complete your daily truth statements.', instructions: isEs ? 'Elige la palabra correcta para completar el decreto sagrado de amor propio.' : 'Select the matching word to complete the empowering affirmation of the day.', emoji: '📝' },
      { id: 'positive_mirror', title: isEs ? 'Espejo positivo' : 'Positive mirror', description: isEs ? 'Mírate con amor. Toca las zonas de tu reflejo para recibir halagos sinceros.' : 'Look at yourself with kindness. Tap your reflection zones to receive affirmations.', instructions: isEs ? 'Toca tu reflejo en el espejo virtual para revelar mensajes de valor interno.' : 'Tap zones of the virtual mirror to reveal deep inner beauty statements.', emoji: '🪞' },
      { id: 'rebuild_self', title: isEs ? 'Reconstruye tu autoestima' : 'Stack self-esteem', description: isEs ? 'Apila los pilares sagrados del amor propio para erigir tu fortaleza.' : 'Stack core pillars of self-love to erect your internal fortress.', instructions: isEs ? 'Suelta las vigas de autoestima (Límites, Respeto, Autocuidado) en balance estable.' : 'Stack self-esteem building blocks in perfect balance to raise a high tower.', emoji: '🏰' }
    ],
    luto: [
      { id: 'balloon_release', title: isEs ? 'Soltar globos' : 'Balloon release', description: isEs ? 'Escribe un recuerdo amoroso o un mensaje para esa persona y déjalo volar.' : 'Write a loving memory and let it fly high into the sunset clouds.', instructions: isEs ? 'Escribe el nombre o recuerdo. Presiona soltar para dejar volar el globo al cielo.' : 'Type a name or message, and release the balloon to the high clouds.', emoji: '🎈' },
      { id: 'healing_letters', title: isEs ? 'Cartas que sanan' : 'Healing letters', description: isEs ? 'Redacta un pensamiento libre y conviértelo en un ave de papel que viaja al infinito.' : 'Write an un-sent letter and watch it fold into an origami dove.', instructions: isEs ? 'Expresa tu luto en palabras y dale al botón para enviarlo como paloma de papel.' : 'Type your feelings, and send to transform it into a flying origami bird.', emoji: '✉️' },
      { id: 'emotional_hug', title: isEs ? 'Abrazo emocional' : 'Emotional embrace', description: isEs ? 'Mantén presionados dos puntos de la pantalla para simular un abrazo contenedor.' : 'Place and hold two fingers to trigger a warm glowing heart embrace.', instructions: isEs ? 'Toca y mantén presionadas las dos huellas dactilares para latir al unísono.' : 'Touch and hold both hands on screen to sync your heartbeat with the warm loop.', emoji: '🫂' }
    ],
    separacion: [
      { id: 'break_chains', title: isEs ? 'Rompe cadenas' : 'Break chains', description: isEs ? 'Toca repetidamente para quebrar las cadenas de la dependencia afectiva.' : 'Tap repeatedly to shatter the heavy chains of dependency.', instructions: isEs ? 'Toca las cadenas doradas con firmeza para agrietarlas y romperlas por completo.' : 'Tap the links repeatedly to crack and shatter emotional dependency bonds.', emoji: '🔗' },
      { id: 'let_go_leaves', title: isEs ? 'Deja ir en el río' : 'Sailing leaves', description: isEs ? 'Coloca recuerdos dolorosos sobre hojas de otoño y míralas navegar río abajo.' : 'Place sad memories on autumn leaves and see them sail down the river.', instructions: isEs ? 'Arrastra o haz clic en los recuerdos viejos para ponerlos en hojas y verlos fluir lejos.' : 'Put heavy relation memories onto leaves and let them float out of your view.', emoji: '🍁' },
      { id: 'new_beginning', title: isEs ? 'Nuevo comienzo' : 'New cozy home', description: isEs ? 'Decora tu nuevo espacio personal paso a paso con amor y tranquilidad.' : 'Design your new cozy personal bedroom step by step with serenity.', instructions: isEs ? 'Elige objetos (libros, taza, plantas, gato) para ordenar tu nueva vida.' : 'Select cozy elements to assemble your beautiful private room layout.', emoji: '🔑' }
    ],
    miedo: [
      { id: 'face_shadows', title: isEs ? 'Enfrenta sombras' : 'Face the shadows', description: isEs ? 'Toca las sombras grises flotantes para convertirlas en faroles brillantes.' : 'Tap floating dark shadow clouds to turn them into colorful hot air balloons.', instructions: isEs ? 'Toca las nubes de dudas y observa cómo se disuelven en luz.' : 'Tap the shadow blocks to light them up and turn them into floating lanterns.', emoji: '🏮' },
      { id: 'inner_light', title: isEs ? 'Luz interior' : 'Inner light exploration', description: isEs ? 'Usa tu linterna para explorar el espacio oscuro y hallar las gemas de paz.' : 'Drag your light beam to explore the darkness and locate hidden gems.', instructions: isEs ? 'Mueve el haz de luz con el dedo para descubrir palabras de aliento ocultas.' : 'Move your cursor/finger over the canvas to find hidden words of power.', emoji: '🔦' }
    ],
    culpa: [
      { id: 'release_stones', title: isEs ? 'Libera piedras' : 'Release heavy stones', description: isEs ? 'Saca las piedras de culpa de tu mochila y lánzalas al fondo del mar.' : 'Remove heavy stones of guilt from your backpack and drop them into the ocean.', instructions: isEs ? 'Arrastra las piedras pesadas fuera de la mochila y colócalas en el mar azul.' : 'Drag the heavy stones labeled with guilt out of the bag and drop them deep.', emoji: '🪨' },
      { id: 'conscious_forgiveness', title: isEs ? 'Perdón consciente' : 'Conscious forgiveness wave', description: isEs ? 'Escribe tus errores pasados y deja que una marea sanadora los borre de la arena.' : 'Write down mistakes and let a healing ocean wave wash them away completely.', instructions: isEs ? 'Escribe aquello de lo que te culpas y mira cómo el oleaje lo limpia todo.' : 'Write what you blame yourself for, then trigger the sea tide to wash it clean.', emoji: '🌊' }
    ]
  };

  // Get current game of the day for an emotion
  const getGameOfDay = (emotionId: string) => {
    const list = gamesByEmotion[emotionId] || [];
    if (list.length === 0) return null;
    
    // Day of the year rotation engine
    const today = new Date();
    const start = new Date(today.getFullYear(), 0, 0);
    const diff = today.getTime() - start.getTime();
    const oneDay = 1000 * 60 * 60 * 24;
    const dayOfYear = Math.floor(diff / oneDay);
    
    const index = dayOfYear % list.length;
    return list[index];
  };

  const handleSelectEmotion = (emotionId: string) => {
    setSelectedEmotion(emotionId);
    const game = getGameOfDay(emotionId);
    setActiveGame(game);
    // Initialize specific game state
    setGameState({
      score: 0,
      progress: 0,
      completed: false,
      step: 0,
      items: initGameItems(game?.id)
    });
    audioSynth.playBell(523.25); // chime
  };

  const initGameItems = (gameId: string | undefined) => {
    if (!gameId) return [];
    if (gameId === 'pop_bubbles') {
      return Array.from({ length: 6 }).map((_, i) => ({
        id: i,
        x: Math.random() * 80 + 10,
        y: Math.random() * 60 + 20,
        size: Math.random() * 20 + 35,
        color: ['bg-rose-400/70', 'bg-amber-400/70', 'bg-purple-400/70', 'bg-teal-400/70', 'bg-blue-400/70'][i % 5]
      }));
    }
    if (gameId === 'catch_calm') {
      return Array.from({ length: 5 }).map((_, i) => ({
        id: i,
        x: Math.random() * 80 + 10,
        y: Math.random() * -30 - 10,
        speed: Math.random() * 2 + 1.5,
        color: ['bg-pink-400', 'bg-yellow-300', 'bg-teal-300', 'bg-emerald-300'][i % 4]
      }));
    }
    if (gameId === 'order_chaos') {
      const words = isEs 
        ? ['Angustia', 'Estrés', 'Confusión', 'Calma', 'Paz', 'Plenitud']
        : ['Anguish', 'Stress', 'Confusion', 'Calm', 'Peace', 'Joy'];
      // Shuffle words randomly
      return words.map((w, i) => ({ text: w, id: i, order: i })).sort(() => Math.random() - 0.5);
    }
    if (gameId === 'sort_thoughts') {
      return [
        { id: 1, text: isEs ? 'No sirvo para esto' : 'I am not good at this', type: 'negative' },
        { id: 2, text: isEs ? 'Merezco amor y límites' : 'I deserve love & boundaries', type: 'positive' },
        { id: 3, text: isEs ? 'Es mi culpa su enojo' : 'Their anger is my fault', type: 'negative' },
        { id: 4, text: isEs ? 'Hago mi mejor esfuerzo' : 'I am doing my best', type: 'positive' },
        { id: 5, text: isEs ? 'Debo soportarlo todo' : 'I must bear everything', type: 'negative' },
        { id: 6, text: isEs ? 'Elijo mi bienestar sin culpa' : 'I choose my wellness guilt-free', type: 'positive' }
      ];
    }
    if (gameId === 'relaxing_puzzle') {
      // 3x3 tiles, each with rotation state
      return Array.from({ length: 9 }).map((_, i) => ({
        id: i,
        rot: Math.floor(Math.random() * 3 + 1) * 90 // 90, 180, 270 degrees
      }));
    }
    if (gameId === 'rebuild_garden') {
      return Array.from({ length: 6 }).map((_, i) => ({
        id: i,
        planted: false,
        flower: ''
      }));
    }
    if (gameId === 'light_sky') {
      return Array.from({ length: 8 }).map((_, i) => ({
        id: i,
        lit: false,
        x: [15, 30, 45, 60, 75, 25, 55, 70][i],
        y: [20, 40, 15, 35, 25, 60, 50, 65][i]
      }));
    }
    if (gameId === 'complete_affirmations') {
      return {
        prompt: isEs ? 'Yo soy ________ y merezco sanar.' : 'I am ________ and I deserve to heal.',
        options: isEs ? ['Débil', 'Suficiente', 'Culpable', 'Incansable'] : ['Weak', 'Enough', 'Guilty', 'Tired'],
        correctIdx: 1
      };
    }
    if (gameId === 'break_chains') {
      return Array.from({ length: 4 }).map((_, i) => ({ id: i, health: 3 }));
    }
    if (gameId === 'let_go_leaves') {
      return [
        { id: 1, text: isEs ? 'Su opinión' : 'Their opinion', x: 20 },
        { id: 2, text: isEs ? 'Las falsas promesas' : 'False promises', x: 50 },
        { id: 3, text: isEs ? 'La necesidad de arreglarlo' : 'The need to fix them', x: 80 }
      ];
    }
    if (gameId === 'release_stones') {
      return [
        { id: 1, text: isEs ? 'Expectativas ajenas' : 'Others expectations', weight: '10kg' },
        { id: 2, text: isEs ? 'Errores del pasado' : 'Past mistakes', weight: '15kg' },
        { id: 3, text: isEs ? 'Culpas impuestas' : 'Imposed guilt', weight: '20kg' }
      ];
    }
    return [];
  };

  const handleFinishGame = (xpAmount: number) => {
    setEarnedXP(xpAmount);
    setShowCelebration(true);
    onGainXP(xpAmount);
    audioSynth.playBell(659.25); // high beautiful E5 chime
  };

  const resetSelection = () => {
    setSelectedEmotion(null);
    setActiveGame(null);
    setGameState({});
  };

  // Gameloop helper for catch_calm
  useEffect(() => {
    if (!activeGame || activeGame.id !== 'catch_calm' || showCelebration) return;
    const interval = setInterval(() => {
      setGameState((prev: any) => {
        if (!prev.items) return prev;
        let missedCount = 0;
        const updatedItems = prev.items.map((item: any) => {
          let newY = item.y + item.speed;
          if (newY > 100) {
            newY = -10; // reset to top
            missedCount++;
          }
          return { ...item, y: newY };
        });
        return { ...prev, items: updatedItems };
      });
    }, 40);
    return () => clearInterval(interval);
  }, [activeGame, showCelebration]);

  return (
    <div className={`fixed inset-0 z-40 flex flex-col overflow-y-auto ${
      currentTheme === 'dark' ? 'bg-neutral-950 text-white' : 'bg-gradient-to-b from-rose-50/50 via-amber-50/20 to-white text-neutral-850'
    }`}>
      {/* Header Bar */}
      <header className={`px-4 py-4 flex items-center justify-between border-b backdrop-blur-md sticky top-0 z-50 ${
        currentTheme === 'dark' ? 'bg-neutral-950/90 border-neutral-850' : 'bg-white/90 border-rose-100/30'
      }`}>
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-rose-400 to-amber-300 flex items-center justify-center text-white shadow-sm">
            <Trophy className="w-4 h-4 fill-rose-100" />
          </div>
          <div>
            <h1 className="font-extrabold text-sm md:text-base tracking-tight leading-none">
              Mind Games Premium
            </h1>
            <p className="text-[10px] text-rose-400 font-bold uppercase tracking-wider mt-0.5">
              {isEs ? 'Gimnasia Emocional Diaria' : 'Daily Emotional Balance'}
            </p>
          </div>
        </div>
        <button 
          onClick={onClose}
          className="p-1.5 rounded-full hover:bg-neutral-150 transition-colors cursor-pointer text-neutral-400"
        >
          <X className="w-5 h-5" />
        </button>
      </header>

      {/* Main Container */}
      <main className="flex-1 max-w-lg w-full mx-auto p-4 pb-24 flex flex-col justify-center">
        <AnimatePresence mode="wait">
          {!selectedEmotion ? (
            /* PHASE 1: EMOTION CHOICE */
            <motion.div
              key="select-emotion"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-6 text-center py-6"
            >
              <div className="space-y-2">
                <span className="text-[10px] bg-rose-500/10 text-rose-400 font-black px-3 py-1 rounded-full uppercase tracking-widest">
                  {isEs ? 'Elige tu Estado' : 'Choose Your State'}
                </span>
                <h2 className="text-2xl font-black tracking-tight leading-snug">
                  {isEs ? '¿Qué emoción deseas armonizar hoy?' : 'Which feeling do you want to soothe today?'}
                </h2>
                <p className="text-xs text-neutral-400 max-w-sm mx-auto">
                  {isEs 
                    ? 'Cada categoría contiene juegos interactivos diseñados para calmar el sistema nervioso, ganar XP y desbloquear calma.'
                    : 'Each category hosts interactive mini-games calibrated to restore calm, build XP and release stress.'}
                </p>
              </div>

              {/* Grid of Emotions */}
              <div className="grid grid-cols-2 gap-3 max-w-md mx-auto pt-2">
                {emotions.map((em) => (
                  <motion.button
                    key={em.id}
                    whileHover={{ scale: 1.03 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={() => handleSelectEmotion(em.id)}
                    className="p-5 rounded-3xl border text-left bg-white shadow-sm flex flex-col justify-between h-32 transition-all cursor-pointer border-rose-100/50 hover:border-rose-400 text-neutral-800"
                  >
                    <span className="text-3xl">{em.emoji}</span>
                    <div>
                      <h4 className="font-extrabold text-sm tracking-tight">{em.label}</h4>
                      <p className="text-[9px] text-neutral-400 font-semibold uppercase tracking-wider mt-0.5">
                        {isEs ? 'Juego de hoy' : 'Today game'}
                      </p>
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          ) : (
            /* PHASE 2: ACTIVE GAMEPLAY */
            <motion.div
              key="gameplay"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="space-y-6"
            >
              {/* Back Button */}
              <div className="flex items-center justify-between">
                <button 
                  onClick={resetSelection}
                  className="text-xs font-bold text-rose-400 flex items-center gap-1 hover:underline cursor-pointer"
                >
                  ← {isEs ? 'Cambiar Emoción' : 'Change Emotion'}
                </button>
                <div className="text-xs font-black uppercase tracking-widest text-rose-400 bg-rose-500/10 px-2.5 py-1 rounded-full">
                  {emotions.find(e => e.id === selectedEmotion)?.label}
                </div>
              </div>

              {/* Game Card */}
              <div className={`p-6 rounded-3xl border relative shadow-xl overflow-hidden ${
                currentTheme === 'dark' ? 'bg-neutral-900/80 border-neutral-800' : 'bg-white border-rose-100/50'
              }`}>
                {/* Info Header */}
                <div className="flex items-start gap-4 mb-4 pb-4 border-b border-rose-100/10">
                  <span className="text-4xl">{activeGame?.emoji}</span>
                  <div>
                    <h3 className="text-lg font-extrabold tracking-tight text-rose-500">
                      {activeGame?.title}
                    </h3>
                    <p className="text-xs text-neutral-400 leading-relaxed mt-1">
                      {activeGame?.description}
                    </p>
                  </div>
                </div>

                {/* Sub-Instructions */}
                <div className="text-[10px] text-neutral-400 italic mb-4 bg-neutral-100/5 p-2.5 rounded-xl border border-rose-100/5">
                  💡 {activeGame?.instructions}
                </div>

                {/* GAME GRAPHICS CANVAS CONTAINER */}
                <div className="w-full h-64 rounded-2xl bg-neutral-950/5 border border-rose-100/10 relative overflow-hidden flex items-center justify-center p-4">
                  {/* GAME 1: sigue_respiracion */}
                  {activeGame?.id === 'breathe_follow' && (
                    <div className="flex flex-col items-center justify-center w-full space-y-8">
                      <motion.div
                        animate={{
                          scale: gameState.breathing === 'inhaling' ? 1.5 : gameState.breathing === 'exhaling' ? 0.9 : 1,
                          rotate: gameState.breathing === 'inhaling' ? 45 : 0
                        }}
                        transition={{ duration: 4, ease: 'easeInOut' }}
                        className="w-24 h-24 bg-gradient-to-tr from-rose-400 to-amber-300 rounded-full flex items-center justify-center shadow-lg"
                      >
                        <span className="text-3xl text-white">🌸</span>
                      </motion.div>
                      <button
                        onMouseDown={() => {
                          setGameState({ ...gameState, breathing: 'inhaling' });
                          audioSynth.playBell(392.00); // sound
                        }}
                        onMouseUp={() => {
                          setGameState({ ...gameState, breathing: 'exhaling' });
                          audioSynth.playBell(523.25); // chord sound
                          setTimeout(() => {
                            handleFinishGame(45);
                          }, 3000);
                        }}
                        onTouchStart={() => {
                          setGameState({ ...gameState, breathing: 'inhaling' });
                          audioSynth.playBell(392.00);
                        }}
                        onTouchEnd={() => {
                          setGameState({ ...gameState, breathing: 'exhaling' });
                          audioSynth.playBell(523.25);
                          setTimeout(() => {
                            handleFinishGame(45);
                          }, 3000);
                        }}
                        className="px-6 py-3 bg-rose-400 hover:bg-rose-500 text-white font-extrabold text-xs rounded-full uppercase tracking-widest shadow-md cursor-pointer select-none"
                      >
                        {gameState.breathing === 'inhaling' ? (isEs ? 'Sostén / Suelta para exhalar' : 'Hold / Release to exhale') : (isEs ? 'Mantén presionado para inhalar' : 'Press & hold to inhale')}
                      </button>
                    </div>
                  )}

                  {/* GAME 2: pop_bubbles */}
                  {activeGame?.id === 'pop_bubbles' && (
                    <div className="absolute inset-0">
                      {gameState.items?.map((bub: any) => (
                        <motion.button
                          key={bub.id}
                          onClick={() => {
                            audioSynth.playBell(800 + bub.id * 50);
                            setGameState((prev: any) => {
                              const remaining = prev.items.filter((i: any) => i.id !== bub.id);
                              if (remaining.length === 0) {
                                setTimeout(() => handleFinishGame(40), 500);
                              }
                              return { ...prev, items: remaining };
                            });
                          }}
                          className={`absolute rounded-full border border-white/20 shadow-md ${bub.color} flex items-center justify-center cursor-pointer`}
                          style={{
                            left: `${bub.x}%`,
                            top: `${bub.y}%`,
                            width: `${bub.size}px`,
                            height: `${bub.size}px`
                          }}
                          whileTap={{ scale: 1.4, opacity: 0 }}
                        >
                          <span className="text-[9px] font-black text-white/80">POP</span>
                        </motion.button>
                      ))}
                    </div>
                  )}

                  {/* GAME 3: catch_calm */}
                  {activeGame?.id === 'catch_calm' && (
                    <div className="absolute inset-0">
                      <div className="absolute top-2 left-2 text-xs font-bold text-rose-400">
                        {isEs ? 'Atrapados:' : 'Caught:'} {gameState.score || 0} / 6
                      </div>
                      {gameState.items?.map((item: any) => (
                        <motion.button
                          key={item.id}
                          onClick={() => {
                            audioSynth.playBell(600 + Math.random() * 200);
                            setGameState((prev: any) => {
                              const nextScore = (prev.score || 0) + 1;
                              if (nextScore >= 6) {
                                setTimeout(() => handleFinishGame(40), 300);
                              }
                              const resetItems = prev.items.map((it: any) => 
                                it.id === item.id 
                                  ? { ...it, y: -10, x: Math.random() * 80 + 10 } 
                                  : it
                              );
                              return { ...prev, score: nextScore, items: resetItems };
                            });
                          }}
                          className={`absolute w-8 h-8 rounded-full ${item.color} filter blur-sm animate-pulse flex items-center justify-center cursor-pointer`}
                          style={{
                            left: `${item.x}%`,
                            top: `${item.y}%`
                          }}
                        >
                          ✨
                        </motion.button>
                      ))}
                    </div>
                  )}

                  {/* GAME 4: breathe_slide */}
                  {activeGame?.id === 'breathe_slide' && (
                    <div className="flex flex-col items-center justify-center space-y-4 w-full">
                      <div className="text-xs font-bold text-neutral-400">
                        {isEs ? 'Desliza hacia arriba para inhalar, abajo para exhalar' : 'Slide up to inhale, slide down to exhale'}
                      </div>
                      <div className="relative h-44 w-12 bg-neutral-200/20 rounded-full border border-rose-100/10 flex flex-col justify-end p-1">
                        <motion.div
                          animate={{ y: gameState.slideY || 0 }}
                          className="w-10 h-10 bg-gradient-to-tr from-rose-400 to-amber-300 rounded-full shadow-md flex items-center justify-center cursor-pointer"
                          drag="y"
                          dragConstraints={{ top: -140, bottom: 0 }}
                          onDrag={(e, info) => {
                            const val = info.point.y;
                            setGameState({ ...gameState, slideY: info.offset.y });
                            if (info.offset.y < -120 && !gameState.topCompleted) {
                              audioSynth.playBell(587.33); // high D note
                              gameState.topCompleted = true;
                            }
                            if (info.offset.y > -10 && gameState.topCompleted) {
                              audioSynth.playBell(523.25); // completed!
                              handleFinishGame(40);
                            }
                          }}
                        >
                          🍃
                        </motion.div>
                      </div>
                    </div>
                  )}

                  {/* GAME 5: order_chaos */}
                  {activeGame?.id === 'order_chaos' && (
                    <div className="flex flex-col items-center justify-center space-y-4 w-full h-full">
                      <p className="text-xs font-bold text-neutral-400">
                        {isEs ? 'Toca las palabras de menor a mayor tensión para ordenarlas:' : 'Tap words from lowest to highest tension:'}
                      </p>
                      <div className="flex flex-wrap gap-2 justify-center">
                        {gameState.items?.map((item: any) => (
                          <motion.button
                            key={item.id}
                            onClick={() => {
                              audioSynth.playBell(440 + item.order * 60);
                              setGameState((prev: any) => {
                                const currentStep = prev.step || 0;
                                if (item.order === currentStep) {
                                  const updated = prev.items.filter((i: any) => i.id !== item.id);
                                  const nextStep = currentStep + 1;
                                  if (nextStep >= 6) {
                                    setTimeout(() => handleFinishGame(45), 300);
                                  }
                                  return { ...prev, step: nextStep, items: updated };
                                } else {
                                  // Wrong order shake
                                  audioSynth.playBell(220.00); // low warning note
                                  return prev;
                                }
                              });
                            }}
                            whileTap={{ scale: 0.95 }}
                            className="px-3 py-2 bg-rose-400 hover:bg-rose-500 text-white font-extrabold text-xs rounded-xl shadow cursor-pointer border border-white/15"
                          >
                            {item.text}
                          </motion.button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* GAME 6: sort_thoughts */}
                  {activeGame?.id === 'sort_thoughts' && (
                    <div className="flex flex-col justify-between items-center w-full h-full">
                      {gameState.items && gameState.items.length > 0 ? (
                        <div className="text-center space-y-6 pt-4">
                          <span className="text-[10px] bg-amber-400/20 text-amber-500 font-bold px-2.5 py-1 rounded-full">
                            {isEs ? 'Pensamiento surgido:' : 'Arising thought:'}
                          </span>
                          <motion.h4
                            key={gameState.items[0].id}
                            initial={{ scale: 0.9, opacity: 0 }}
                            animate={{ scale: 1, opacity: 1 }}
                            className="text-sm font-black text-white bg-neutral-900 px-4 py-3 rounded-2xl border border-rose-100/10 shadow-inner max-w-xs mx-auto"
                          >
                            "{gameState.items[0].text}"
                          </motion.h4>
                          
                          <div className="flex gap-4">
                            <button
                              onClick={() => {
                                audioSynth.playBell(300);
                                setGameState((prev: any) => {
                                  const item = prev.items[0];
                                  if (item.type === 'negative') {
                                    // Correct trash sorting!
                                    onGainXP(10);
                                  }
                                  const remaining = prev.items.slice(1);
                                  if (remaining.length === 0) {
                                    setTimeout(() => handleFinishGame(50), 300);
                                  }
                                  return { ...prev, items: remaining };
                                });
                              }}
                              className="px-4 py-2 bg-neutral-800 text-rose-400 font-bold text-xs rounded-full border border-rose-900/30 cursor-pointer hover:bg-neutral-900"
                            >
                              🗑️ {isEs ? 'Desechar' : 'Trash'}
                            </button>
                            <button
                              onClick={() => {
                                audioSynth.playBell(523.25);
                                setGameState((prev: any) => {
                                  const item = prev.items[0];
                                  if (item.type === 'positive') {
                                    // Correct cherish!
                                    onGainXP(10);
                                  }
                                  const remaining = prev.items.slice(1);
                                  if (remaining.length === 0) {
                                    setTimeout(() => handleFinishGame(50), 300);
                                  }
                                  return { ...prev, items: remaining };
                                });
                              }}
                              className="px-4 py-2 bg-gradient-to-r from-rose-400 to-amber-300 text-white font-bold text-xs rounded-full shadow cursor-pointer"
                            >
                              ❤️ {isEs ? 'Atesorar' : 'Cherish'}
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="text-xs text-neutral-400 font-medium">
                          {isEs ? 'Procesando...' : 'Processing...'}
                        </div>
                      )}
                    </div>
                  )}

                  {/* GAME 7: relaxing_puzzle */}
                  {activeGame?.id === 'relaxing_puzzle' && (
                    <div className="grid grid-cols-3 gap-1.5 w-44 h-44">
                      {gameState.items?.map((tile: any) => (
                        <button
                          key={tile.id}
                          onClick={() => {
                            audioSynth.playBell(300 + tile.id * 40);
                            setGameState((prev: any) => {
                              const updated = prev.items.map((t: any) => 
                                t.id === tile.id ? { ...t, rot: (t.rot + 90) % 360 } : t
                              );
                              // Check if all rotations are 0
                              const isSolved = updated.every((t: any) => t.rot === 0);
                              if (isSolved) {
                                setTimeout(() => handleFinishGame(45), 500);
                              }
                              return { ...prev, items: updated };
                            });
                          }}
                          className="bg-gradient-to-tr from-amber-200/50 to-rose-300/60 rounded-xl relative overflow-hidden flex items-center justify-center border border-white/20 cursor-pointer"
                          style={{
                            transform: `rotate(${tile.rot}deg)`,
                            transition: 'transform 0.3s'
                          }}
                        >
                          <span className="text-lg opacity-80">🌅</span>
                        </button>
                      ))}
                    </div>
                  )}

                  {/* GAME 8: find_balance */}
                  {activeGame?.id === 'find_balance' && (
                    <div className="flex flex-col items-center justify-center space-y-8 w-full">
                      <div className="w-full max-w-xs h-1.5 bg-neutral-200/20 rounded-full relative">
                        <motion.div
                          animate={{ x: (gameState.balanceX || 0) * 1.2 }}
                          className="absolute -top-1.5 left-1/2 w-4.5 h-4.5 bg-yellow-400 rounded-full shadow"
                        />
                      </div>
                      <div className="flex gap-4">
                        <button
                          onClick={() => {
                            audioSynth.playBell(330);
                            setGameState((prev: any) => {
                              const nextX = (prev.balanceX || 0) - 20;
                              if (Math.abs(nextX) < 10) {
                                setTimeout(() => handleFinishGame(40), 1000);
                              }
                              return { ...prev, balanceX: nextX };
                            });
                          }}
                          className="p-3 bg-rose-400/20 text-rose-500 rounded-full cursor-pointer hover:bg-rose-400/30 font-bold"
                        >
                          ◀
                        </button>
                        <button
                          onClick={() => {
                            audioSynth.playBell(350);
                            setGameState((prev: any) => {
                              const nextX = (prev.balanceX || 0) + 20;
                              if (Math.abs(nextX) < 10) {
                                setTimeout(() => handleFinishGame(40), 1000);
                              }
                              return { ...prev, balanceX: nextX };
                            });
                          }}
                          className="p-3 bg-rose-400/20 text-rose-500 rounded-full cursor-pointer hover:bg-rose-400/30 font-bold"
                        >
                          ▶
                        </button>
                      </div>
                    </div>
                  )}

                  {/* GAME 9: rebuild_garden */}
                  {activeGame?.id === 'rebuild_garden' && (
                    <div className="grid grid-cols-3 gap-4 w-full max-w-xs">
                      {gameState.items?.map((spot: any) => (
                        <button
                          key={spot.id}
                          disabled={spot.planted}
                          onClick={() => {
                            audioSynth.playBell(523.25);
                            setGameState((prev: any) => {
                              const updated = prev.items.map((s: any) => 
                                s.id === spot.id ? { planted: true, flower: ['🌹', '🪻', '🌻', '🌸'][Math.floor(Math.random() * 4)] } : s
                              );
                              const isFull = updated.every((s: any) => s.planted);
                              if (isFull) {
                                setTimeout(() => handleFinishGame(45), 600);
                              }
                              return { ...prev, items: updated };
                            });
                          }}
                          className={`h-16 rounded-2xl flex items-center justify-center border transition-all cursor-pointer ${
                            spot.planted 
                              ? 'bg-emerald-500/10 border-emerald-500 text-2xl scale-102' 
                              : 'bg-neutral-800/20 border-rose-100/10 text-neutral-400 hover:border-emerald-300'
                          }`}
                        >
                          {spot.planted ? spot.flower : '🌱'}
                        </button>
                      ))}
                    </div>
                  )}

                  {/* GAME 10: plant_hope */}
                  {activeGame?.id === 'plant_hope' && (
                    <div className="flex flex-col items-center justify-center space-y-4 w-full">
                      {!gameState.planted ? (
                        <div className="w-full max-w-xs space-y-3">
                          <input
                            type="text"
                            value={gameState.hopeText || ''}
                            onChange={(e) => setGameState({ ...gameState, hopeText: e.target.value })}
                            placeholder={isEs ? 'Escribe tu sueño o esperanza...' : 'Enter your dream or hope...'}
                            className="w-full p-3 text-xs bg-white/10 border border-rose-100/10 rounded-xl text-neutral-800 focus:outline-none"
                          />
                          <button
                            onClick={() => {
                              if (!gameState.hopeText) return;
                              audioSynth.playBell(392);
                              setGameState({ ...gameState, planted: true });
                              setTimeout(() => handleFinishGame(50), 3500);
                            }}
                            disabled={!gameState.hopeText}
                            className="w-full py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white font-extrabold text-xs rounded-xl shadow cursor-pointer disabled:opacity-40"
                          >
                            🌱 {isEs ? 'Sembrar Esperanza' : 'Sow Hope'}
                          </button>
                        </div>
                      ) : (
                        <div className="text-center space-y-4">
                          <motion.div
                            initial={{ scale: 0, y: 10 }}
                            animate={{ scale: [1, 1.3, 1.1], y: 0 }}
                            className="text-5xl"
                          >
                            🌳
                          </motion.div>
                          <motion.p
                            initial={{ opacity: 0 }}
                            animate={{ opacity: 1 }}
                            className="text-xs italic font-bold text-emerald-400"
                          >
                            "{gameState.hopeText}"
                          </motion.p>
                          <p className="text-[10px] text-neutral-400">
                            {isEs ? 'Tu esperanza está creciendo fuerte.' : 'Your hope is blossoming into a gorgeous golden leaf.'}
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* GAME 11: light_sky */}
                  {activeGame?.id === 'light_sky' && (
                    <div className="absolute inset-0">
                      {gameState.items?.map((star: any) => (
                        <button
                          key={star.id}
                          onClick={() => {
                            audioSynth.playBell(600 + star.id * 80);
                            setGameState((prev: any) => {
                              const updated = prev.items.map((s: any) => 
                                s.id === star.id ? { ...s, lit: true } : s
                              );
                              const allLit = updated.every((s: any) => s.lit);
                              if (allLit) {
                                setTimeout(() => handleFinishGame(45), 500);
                              }
                              return { ...prev, items: updated };
                            });
                          }}
                          className="absolute w-6 h-6 flex items-center justify-center cursor-pointer"
                          style={{
                            left: `${star.x}%`,
                            top: `${star.y}%`
                          }}
                        >
                          <Star className={`w-5 h-5 ${star.lit ? 'text-yellow-300 fill-yellow-300 drop-shadow-lg' : 'text-neutral-650'}`} />
                        </button>
                      ))}
                    </div>
                  )}

                  {/* GAME 12: complete_affirmations */}
                  {activeGame?.id === 'complete_affirmations' && (
                    <div className="flex flex-col items-center justify-center space-y-6 w-full">
                      <p className="text-sm font-black text-center max-w-xs">
                        "{gameState.items?.prompt}"
                      </p>
                      <div className="grid grid-cols-2 gap-2.5 w-full max-w-xs">
                        {gameState.items?.options?.map((opt: string, i: number) => (
                          <button
                            key={i}
                            onClick={() => {
                              if (i === gameState.items.correctIdx) {
                                audioSynth.playBell(523.25);
                                handleFinishGame(40);
                              } else {
                                audioSynth.playBell(220); // wrong
                              }
                            }}
                            className="p-3 bg-rose-400/10 border border-rose-100/20 text-rose-500 font-bold text-xs rounded-xl hover:bg-rose-400/20 cursor-pointer"
                          >
                            {opt}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* GAME 13: positive_mirror */}
                  {activeGame?.id === 'positive_mirror' && (
                    <div className="flex flex-col items-center justify-center w-full space-y-4">
                      <div className="w-24 h-24 rounded-full border-4 border-rose-300 flex items-center justify-center relative overflow-hidden bg-neutral-900/10">
                        <Smile className="w-12 h-12 text-rose-400" />
                        <div className="absolute inset-0 bg-white/25 backdrop-blur-[1px] rounded-full" />
                      </div>
                      <div className="flex gap-2">
                        {[
                          { id: 1, label: isEs ? 'Mente' : 'Mind', phrase: isEs ? 'Tu mente es brillante y resiliente.' : 'Your mind is bright and resilient.' },
                          { id: 2, label: isEs ? 'Corazón' : 'Heart', phrase: isEs ? 'Mereces darte el mismo amor que regalas.' : 'You deserve the same love you freely give.' },
                          { id: 3, label: isEs ? 'Fuerza' : 'Strength', phrase: isEs ? 'Has superado tormentas más duras.' : 'You have overcome much harder storms.' }
                        ].map(part => (
                          <button
                            key={part.id}
                            onClick={() => {
                              audioSynth.playBell(440 + part.id * 100);
                              setGameState({ ...gameState, reflected: part.phrase });
                              setTimeout(() => handleFinishGame(45), 2500);
                            }}
                            className="px-3 py-1.5 bg-rose-400/10 border border-rose-100/20 hover:bg-rose-400/20 text-rose-500 font-bold text-[10px] rounded-full cursor-pointer"
                          >
                            {part.label}
                          </button>
                        ))}
                      </div>
                      {gameState.reflected && (
                        <motion.p
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="text-xs italic text-center font-extrabold text-rose-500 max-w-xs mt-2"
                        >
                          "{gameState.reflected}"
                        </motion.p>
                      )}
                    </div>
                  )}

                  {/* GAME 14: rebuild_self (stack block) */}
                  {activeGame?.id === 'rebuild_self' && (
                    <div className="flex flex-col items-center justify-end h-full w-full space-y-2 pb-4">
                      <div className="space-y-1.5 w-44">
                        {[
                          { text: isEs ? 'Amor Propio' : 'Self Love', color: 'bg-rose-400' },
                          { text: isEs ? 'Autocuidado' : 'Self Care', color: 'bg-amber-400' },
                          { text: isEs ? 'Límites Sanos' : 'Healthy Limits', color: 'bg-teal-400' },
                          { text: isEs ? 'Respeto' : 'Self Respect', color: 'bg-purple-400' }
                        ].slice(0, (gameState.score || 0) + 1).reverse().map((b, idx) => (
                          <motion.div
                            key={idx}
                            initial={{ scale: 0, y: -20 }}
                            animate={{ scale: 1, y: 0 }}
                            className={`py-2 px-3 text-white font-black text-xs text-center rounded-xl shadow-md ${b.color}`}
                          >
                            {b.text}
                          </motion.div>
                        ))}
                      </div>
                      
                      {gameState.score < 4 && (
                        <button
                          onClick={() => {
                            audioSynth.playBell(300 + (gameState.score || 0) * 100);
                            setGameState((prev: any) => {
                              const nextScore = (prev.score || 0) + 1;
                              if (nextScore >= 4) {
                                setTimeout(() => handleFinishGame(45), 600);
                              }
                              return { ...prev, score: nextScore };
                            });
                          }}
                          className="px-4 py-2 bg-neutral-800 text-white font-black text-xs rounded-xl hover:bg-neutral-900 cursor-pointer"
                        >
                          🏗️ {isEs ? 'Colocar viga de autoestima' : 'Stack self block'}
                        </button>
                      )}
                    </div>
                  )}

                  {/* GAME 15: balloon_release */}
                  {activeGame?.id === 'balloon_release' && (
                    <div className="flex flex-col items-center justify-center space-y-4 w-full">
                      {!gameState.released ? (
                        <div className="w-full max-w-xs space-y-3">
                          <input
                            type="text"
                            value={gameState.balloonText || ''}
                            onChange={(e) => setGameState({ ...gameState, balloonText: e.target.value })}
                            placeholder={isEs ? '¿A quién recuerdas o qué decides soltar?' : 'Who do you miss or what are you letting go?'}
                            className="w-full p-3 text-xs bg-white/10 border border-rose-100/10 rounded-xl text-neutral-800 focus:outline-none"
                          />
                          <button
                            onClick={() => {
                              if (!gameState.balloonText) return;
                              audioSynth.playBell(440);
                              setGameState({ ...gameState, released: true });
                              setTimeout(() => handleFinishGame(50), 3000);
                            }}
                            disabled={!gameState.balloonText}
                            className="w-full py-2.5 bg-rose-400 hover:bg-rose-500 text-white font-extrabold text-xs rounded-xl shadow cursor-pointer disabled:opacity-40"
                          >
                            🎈 {isEs ? 'Soltar Globo al Cielo' : 'Release Balloon'}
                          </button>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center">
                          <motion.div
                            animate={{ y: -150, opacity: [1, 0.8, 0] }}
                            transition={{ duration: 3.5, ease: 'easeOut' }}
                            className="w-16 h-16 rounded-full bg-rose-400 flex items-center justify-center text-white text-3xl shadow-lg relative"
                          >
                            🎈
                          </motion.div>
                          <p className="text-xs text-neutral-400 mt-4 max-w-xs text-center italic">
                            "{gameState.balloonText}" {isEs ? 'ha sido liberado con amor.' : 'released to the high clouds.'}
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* GAME 16: healing_letters */}
                  {activeGame?.id === 'healing_letters' && (
                    <div className="flex flex-col items-center justify-center space-y-4 w-full">
                      {!gameState.sent ? (
                        <div className="w-full max-w-xs space-y-3">
                          <textarea
                            value={gameState.letterText || ''}
                            onChange={(e) => setGameState({ ...gameState, letterText: e.target.value })}
                            placeholder={isEs ? 'Escribe tu carta sincera...' : 'Write your healing unsent letter...'}
                            className="w-full h-20 p-3 text-xs bg-white/10 border border-rose-100/10 rounded-xl text-neutral-800 resize-none focus:outline-none"
                          />
                          <button
                            onClick={() => {
                              if (!gameState.letterText) return;
                              audioSynth.playBell(523.25);
                              setGameState({ ...gameState, sent: true });
                              setTimeout(() => handleFinishGame(50), 3000);
                            }}
                            disabled={!gameState.letterText}
                            className="w-full py-2.5 bg-indigo-500 hover:bg-indigo-600 text-white font-extrabold text-xs rounded-xl shadow cursor-pointer"
                          >
                            ✉️ {isEs ? 'Convertir en Paloma y Enviar' : 'Send origami bird'}
                          </button>
                        </div>
                      ) : (
                        <div className="flex flex-col items-center space-y-4">
                          <motion.div
                            animate={{ x: 200, y: -150, rotate: 30, opacity: 0 }}
                            transition={{ duration: 3 }}
                            className="text-4xl"
                          >
                            🕊️
                          </motion.div>
                          <p className="text-xs text-neutral-400 text-center italic">
                            {isEs ? 'Tu carta vuela hacia el infinito sanando tu alma.' : 'Your letter flies away in the breeze.'}
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* GAME 17: emotional_hug */}
                  {activeGame?.id === 'emotional_hug' && (
                    <div className="flex flex-col items-center justify-center space-y-6 w-full">
                      <motion.div
                        animate={{
                          scale: gameState.pressing ? [1, 1.15, 1] : 1
                        }}
                        transition={{ repeat: Infinity, duration: 1.2 }}
                        className="w-20 h-20 bg-gradient-to-tr from-indigo-400 to-rose-400 rounded-full flex items-center justify-center shadow-lg cursor-pointer"
                        onMouseDown={() => {
                          setGameState({ ...gameState, pressing: true });
                          audioSynth.playBell(330);
                          setTimeout(() => {
                            handleFinishGame(45);
                          }, 3000);
                        }}
                        onMouseUp={() => setGameState({ ...gameState, pressing: false })}
                        onTouchStart={() => {
                          setGameState({ ...gameState, pressing: true });
                          audioSynth.playBell(330);
                          setTimeout(() => {
                            handleFinishGame(45);
                          }, 3000);
                        }}
                        onTouchEnd={() => setGameState({ ...gameState, pressing: false })}
                      >
                        <Heart className="w-10 h-10 text-white fill-white/20" />
                      </motion.div>
                      <span className="text-[10px] text-neutral-400 font-bold uppercase tracking-wider text-center">
                        {isEs ? 'Mantén presionado el corazón 3 segundos para darte un abrazo' : 'Hold the heart down for 3 seconds to embrace yourself'}
                      </span>
                    </div>
                  )}

                  {/* GAME 18: break_chains */}
                  {activeGame?.id === 'break_chains' && (
                    <div className="flex flex-col items-center justify-center space-y-6 w-full">
                      <div className="text-xs font-bold text-neutral-400">
                        {isEs ? 'Toca la cadena repetidamente para romperla:' : 'Tap the chain repeatedly to break:'}
                      </div>
                      <div className="flex gap-2">
                        {gameState.items && gameState.items.length > 0 ? (
                          gameState.items.map((link: any) => (
                            <button
                              key={link.id}
                              onClick={() => {
                                audioSynth.playBell(200 + link.id * 100);
                                setGameState((prev: any) => {
                                  const updated = prev.items.map((i: any) => 
                                    i.id === link.id ? { ...i, health: i.health - 1 } : i
                                  ).filter((i: any) => i.health > 0);
                                  if (updated.length === 0) {
                                    setTimeout(() => handleFinishGame(45), 300);
                                  }
                                  return { ...prev, items: updated };
                                });
                              }}
                              className="px-4 py-3 bg-neutral-800 border-2 border-amber-400 text-white font-extrabold text-xs rounded-xl shadow cursor-pointer hover:bg-neutral-900"
                            >
                              🔗 {link.health}
                            </button>
                          ))
                        ) : (
                          <div className="text-emerald-400 text-xs font-bold">
                            {isEs ? '¡Cadenas rotas con éxito! Eres libre.' : 'Chains broken successfully! You are free.'}
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  {/* GAME 19: let_go_leaves */}
                  {activeGame?.id === 'let_go_leaves' && (
                    <div className="flex flex-col items-center justify-center space-y-4 w-full">
                      <p className="text-xs font-bold text-neutral-400">
                        {isEs ? 'Toca los recuerdos dolorosos para soltarlos en el río:' : 'Tap painful relation memories to release them:'}
                      </p>
                      <div className="flex gap-2">
                        {gameState.items?.map((item: any) => (
                          <motion.button
                            key={item.id}
                            onClick={() => {
                              audioSynth.playBell(300);
                              setGameState((prev: any) => {
                                const remaining = prev.items.filter((i: any) => i.id !== item.id);
                                if (remaining.length === 0) {
                                  setTimeout(() => handleFinishGame(45), 500);
                                }
                                return { ...prev, items: remaining };
                              });
                            }}
                            whileTap={{ x: 200, opacity: 0 }}
                            className="px-3 py-2 bg-amber-500/10 border border-amber-300 text-amber-500 font-extrabold text-xs rounded-xl cursor-pointer"
                          >
                            🍁 {item.text}
                          </motion.button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* GAME 20: release_stones */}
                  {activeGame?.id === 'release_stones' && (
                    <div className="flex flex-col items-center justify-center space-y-6 w-full">
                      <p className="text-xs font-bold text-neutral-400">
                        {isEs ? 'Suelta las piedras pesadas fuera de tu mochila:' : 'Remove heavy stones of guilt from your backpack:'}
                      </p>
                      <div className="flex gap-3">
                        {gameState.items?.map((st: any) => (
                          <button
                            key={st.id}
                            onClick={() => {
                              audioSynth.playBell(180);
                              setGameState((prev: any) => {
                                const remaining = prev.items.filter((i: any) => i.id !== st.id);
                                if (remaining.length === 0) {
                                  setTimeout(() => handleFinishGame(50), 300);
                                }
                                return { ...prev, items: remaining };
                              });
                            }}
                            className="p-3 bg-neutral-800 text-neutral-300 font-black text-xs rounded-2xl cursor-pointer border border-neutral-700"
                          >
                            🪨 {st.text} ({st.weight})
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Fallback component if id doesn't match */}
                  {!['breathe_follow', 'pop_bubbles', 'catch_calm', 'breathe_slide', 'order_chaos', 'sort_thoughts', 'relaxing_puzzle', 'find_balance', 'rebuild_garden', 'plant_hope', 'light_sky', 'complete_affirmations', 'positive_mirror', 'rebuild_self', 'balloon_release', 'healing_letters', 'emotional_hug', 'break_chains', 'let_go_leaves', 'release_stones'].includes(activeGame?.id || '') && (
                    <div className="flex flex-col items-center justify-center space-y-4">
                      <span className="text-5xl">🧘</span>
                      <button 
                        onClick={() => handleFinishGame(40)}
                        className="px-6 py-3 bg-rose-400 text-white font-extrabold rounded-full text-xs shadow"
                      >
                        {isEs ? 'Completar Meditación Diaria (+40 XP)' : 'Complete Daily Reflection (+40 XP)'}
                      </button>
                    </div>
                  )}
                </div>

                {/* Return Button */}
                <div className="mt-4 flex justify-between items-center text-xs text-neutral-400 font-medium">
                  <span>✨ Mind Games Suite</span>
                  <span>🏆 Rewards: up to +50 XP</span>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* PHASE 3: CELEBRATION MODAL OVERLAY */}
      <AnimatePresence>
        {showCelebration && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-xl"
          >
            <motion.div
              initial={{ scale: 0.9, y: 30 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 30 }}
              className="max-w-md w-full bg-neutral-900 border border-neutral-800 rounded-3xl p-8 text-center space-y-6 text-white relative overflow-hidden"
            >
              {/* Abstract Particle Background */}
              <div className="absolute top-0 left-0 right-0 h-2 bg-gradient-to-r from-yellow-400 via-rose-500 to-purple-600" />
              
              <div className="w-20 h-20 bg-yellow-400/10 rounded-full flex items-center justify-center mx-auto text-4xl text-yellow-400 shadow-lg border border-yellow-400/20">
                ⭐
              </div>

              <div className="space-y-2">
                <h2 className="text-2xl font-black tracking-tight text-yellow-300">
                  {isEs ? '¡Fantástico trabajo! 🌸' : 'Amazing effort! 🌸'}
                </h2>
                <p className="text-xs text-neutral-400 max-w-sm mx-auto leading-relaxed">
                  {isEs 
                    ? `Has completado el juego mental con éxito. El amor propio florece en ti con cada pequeña decisión consciente, ${userState.name || ''}.` 
                    : `You have completed the daily mind game successfully. Your emotional balance grows stronger with every choice, ${userState.name || ''}.`}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-neutral-950/60 border border-neutral-800 inline-block">
                <span className="text-xs uppercase font-extrabold tracking-widest text-neutral-400 block mb-1">
                  {isEs ? 'Recompensas obtenidas' : 'Reward earned'}
                </span>
                <span className="text-2xl font-black text-yellow-400">
                  +{earnedXP} XP
                </span>
              </div>

              <button
                onClick={() => {
                  setShowCelebration(false);
                  resetSelection();
                }}
                className="w-full py-3.5 bg-yellow-400 hover:bg-yellow-500 text-neutral-900 font-extrabold text-sm rounded-2xl shadow-lg shadow-yellow-400/10 cursor-pointer"
              >
                {isEs ? 'Aceptar y Continuar' : 'Awesome, Continue'}
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
