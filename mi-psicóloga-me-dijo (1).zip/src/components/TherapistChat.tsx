import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Send, Heart, Compass, Sparkles, MessageCircle, RefreshCw } from 'lucide-react';
import { Language, ChatMessage, UserState } from '../types';

interface TherapistChatProps {
  language: Language;
  userState: UserState;
  onGainXP: (amount: number) => void;
  userId: string;
  initialTopicMessage?: string | null;
  onClearInitialTopic?: () => void;
}

export default function TherapistChat({ language, userState, onGainXP, userId, initialTopicMessage, onClearInitialTopic }: TherapistChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Set initial empathetic welcome based on language
  useEffect(() => {
    const welcomeMessages: Record<Language, string> = {
      es: `Hola ${userState.name || ''} 🌸, soy Olivia Miller. Estoy aquí para acompañarte sin filtros ni juicios. Cuéntame, ¿qué situación te está drenando la energía o de qué te has cansado hoy?`,
      en: `Hello ${userState.name || ''} 🌸, I am Olivia Miller. I am here to walk alongside you without filters or judgment. Tell me, what situation is draining your energy or what are you tired of today?`,
      pt: `Olá ${userState.name || ''} 🌸, sou Olivia Miller. Estou aqui para acompanhá-la sem filtros ou julgamentos. Diga-me, qual situação está drenando sua energia ou do que você se cansou hoje?`,
      it: `Ciao ${userState.name || ''} 🌸, sono Olivia Miller. Sono qui per accompagnarti senza filtri o giudizi. Dimmi, quale situazione sta esaurendo la tua energia o di cosa ti sei stancata oggi?`,
      fr: `Bonjour ${userState.name || ''} 🌸, je suis Olivia Miller. Je suis ici pour vous accompagner sans filtre ni jugement. Dites-moi, quelle situation draine votre énergie ou de quoi êtes-vous fatiguée aujourd\'hui ?`,
      de: `Hallo ${userState.name || ''} 🌸, ich bin Olivia Miller. Ich bin hier, um dich ohne Filter und Urteile zu begleiten. Erzähl mir, welche Situation raubt dir heute die Energie oder wovon bist du müde geworden?`,
      nl: `Hallo ${userState.name || ''} 🌸, ik ben Olivia Miller. Ik ben hier om je te begeleiden zonder filters of oordelen. Vertel me, welke situatie put je energie uit of waar ben je vandaag moe van geworden?`,
      ca: `Hola ${userState.name || ''} 🌸, sóc l’Olivia Miller. Sóc aquí per acompanyar-te sense filtres ni judicis. Explica’m, quina situació t’està drenant l’energia o de què t’has cansat avui?`,
    };

    if (initialTopicMessage) {
      setMessages([
        {
          id: 'welcome-topic',
          sender: 'therapist',
          text: initialTopicMessage,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
      if (onClearInitialTopic) {
        onClearInitialTopic();
      }
    } else {
      setMessages([
        {
          id: 'welcome',
          sender: 'therapist',
          text: welcomeMessages[language] || welcomeMessages['es'],
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    }
  }, [language, userState.name, initialTopicMessage]);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isThinking]);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isThinking) return;

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: inputText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText('');
    setIsThinking(true);

    try {
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMsg.text,
          mood: userState.moodHistory[new Date().toISOString().split('T')[0]] || 'ansiosa',
          language,
          userId,
          chatHistory: [...messages, userMsg],
          userState,
        }),
      });

      const data = await response.json();
      setIsThinking(false);

      if (data.reply) {
        const therapistMsg: ChatMessage = {
          id: (Date.now() + 1).toString(),
          sender: 'therapist',
          text: data.reply,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        };
        setMessages(prev => [...prev, therapistMsg]);
        onGainXP(15); // Empathy conversation gain
      } else {
        throw new Error('No reply from therapist API');
      }
    } catch (err) {
      setIsThinking(false);
      // Fallback response with wisdom quotes from the book if server fails
      const fallbacks: Record<Language, string> = {
        es: 'Entiendo perfectamente tu dolor. En el libro "Mi Psicóloga Me Dijo" suelo recordar esto: "A veces lo único que necesitas es dejar de exigirte tanto y empezar a abrazarte tal como estás: rota, triste, agotada. Porque así, con todo y tus grietas, eres suficiente." Cuéntame más sobre cómo resuena esto en ti.',
        en: 'I completely understand your pain. In my sessions, I always remind people: "Sometimes the only thing you need is to stop demanding so much of yourself and start embracing yourself just as you are: broken, sad, exhausted. Because just like that, with all your cracks, you are enough." Tell me more about how this lands with you.',
        pt: 'Entendo perfeitamente a sua dor. Em minhas sessões, sempre lembro as pessoas: "Às vezes, a única coisa de que você precisa é parar de se cobrar tanto e começar a se acolher exatamente como você está: quebrada, triste, exausta. Porque assim, com todas as suas rachaduras, você é suficiente." Conte-me mais sobre como isso soa para você.',
        it: 'Comprendo perfettamente il tuo dolore. Nelle mie sessioni ricordo sempre: "A volte l\'unica cosa di cui hai bisogno è smettere di pretendere così tanto da te stessa e iniziare ad abbracciarti così come sei: a pezzi, triste, esausta. Perché così, con tutte le tue crepe, sei abbastanza." Raccontami di più su come ti risuona questo pensiero.',
        fr: 'Je comprends parfaitement votre douleur. Dans mes séances, je rappelle toujours : "Parfois, la seule chose dont vous avez besoin est d\'arrêter de tant exiger de vous-même et de commencer à vous accepter telle que vous êtes : brisée, triste, épuisée. Car ainsi, avec toutes vos fissures, vous êtes suffisante." Dites-m\'en plus sur la façon dont cela résonne en vous.',
        de: 'Ich verstehe deinen Schmerz vollkommen. In meinen Sitzungen erinnere ich die Menschen immer daran: "Manchmal ist das Einzige, was du tun musst, aufzuhören, so viel von dir zu verlangen, und dich so zu umarmen, wie du bist: zerbrochen, traurig, erschöpft. Denn genau so, mit all deinen Rissen, bist du genug." Erzähl mir mehr darüber, wie das bei dir ankommt.',
        nl: 'Ik begrijp je pijn volkomen. In mijn sessies herinner ik mensen er altijd aan: "Soms is het enige wat je hoeft te doen, ophouden met zoveel van jezelf te eisen en jezelf te omarmen zoals je bent: gebroken, verdrietig, uitgeput. Want precies zo, met al je scheuren, ben je genoeg." Vertel me meer over hoe dit bij jou binnenkomt.',
        ca: 'Entenc perfectament el teu dolor. Al llibre solen recordar això: "A vegades l\'únic que necessites és deixar d\'exigir-te tant i començar a abraçar-te tal com estàs: trencada, trista, esgotada. Perquè així, amb totes les teves esquerdes, ets suficient." Explica’m com et ressona això.',
      };

      const therapistMsg: ChatMessage = {
        id: (Date.now() + 1).toString(),
        sender: 'therapist',
        text: fallbacks[language] || fallbacks['es'],
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages(prev => [...prev, therapistMsg]);
    }
  };

  const currentTheme = userState.theme;

  return (
    <div id="therapist-chat-container" className="flex flex-col h-[calc(100vh-140px)] max-w-lg mx-auto">
      {/* Premium Therapist Header Card */}
      <div className={`p-4 rounded-3xl mb-4 flex items-center justify-between border shadow-sm ${
        currentTheme === 'dark' 
          ? 'bg-neutral-900/60 border-neutral-800' 
          : 'bg-white/80 border-rose-100/50'
      }`}>
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-rose-400 to-amber-300 flex items-center justify-center text-white text-lg font-bold shadow-md">
              OM
            </div>
            <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-400 border-2 border-white rounded-full"></span>
          </div>
          <div>
            <h3 className={`font-semibold tracking-tight ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
              Olivia Miller
            </h3>
            <p className="text-xs text-rose-400 font-medium flex items-center gap-1">
              <Sparkles className="w-3 h-3" />
              {language === 'es' ? 'Terapeuta Virtual Autorizada' : 'Empathetic AI Companion'}
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Heart className="w-5 h-5 text-rose-400 fill-rose-100" />
        </div>
      </div>

      {/* Chat History Panel */}
      <div className={`flex-1 overflow-y-auto p-4 rounded-3xl border mb-4 space-y-4 scrollbar-thin ${
        currentTheme === 'dark'
          ? 'bg-neutral-950/40 border-neutral-900'
          : 'bg-gradient-to-b from-rose-50/20 to-amber-50/20 border-rose-100/30'
      }`}>
        <AnimatePresence initial={false}>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] px-4 py-3 rounded-2xl shadow-sm text-sm leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-gradient-to-r from-rose-400 to-coral-400 text-white rounded-tr-none'
                    : currentTheme === 'dark'
                      ? 'bg-neutral-900 text-neutral-200 border border-neutral-800 rounded-tl-none'
                      : 'bg-white text-neutral-800 border border-rose-100/50 rounded-tl-none'
                }`}
              >
                <p className="whitespace-pre-line">{msg.text}</p>
              </div>
              <span className="text-[10px] text-neutral-400 mt-1 px-1">{msg.timestamp}</span>
            </motion.div>
          ))}
        </AnimatePresence>

        {isThinking && (
          <div className="flex items-center gap-2 text-rose-400 text-xs font-medium px-2 py-1 bg-rose-50/50 rounded-full w-fit">
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            <span>
              {language === 'es' ? 'Olivia está reflexionando...' : 'Olivia is reflecting...'}
            </span>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input Box */}
      <form onSubmit={handleSend} className="relative flex items-center">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder={
            language === 'es' ? 'Escribe algo con total confianza...' : 'Write with complete trust...'
          }
          className={`w-full py-4 pl-5 pr-14 rounded-full border focus:outline-none focus:ring-2 focus:ring-rose-300 text-sm shadow-sm transition-all duration-300 ${
            currentTheme === 'dark'
              ? 'bg-neutral-900 border-neutral-800 text-white placeholder-neutral-500 focus:ring-rose-500'
              : 'bg-white border-rose-100/70 text-neutral-800 placeholder-neutral-400'
          }`}
        />
        <button
          id="send-chat-message-btn"
          type="submit"
          disabled={!inputText.trim() || isThinking}
          className={`absolute right-2 p-3 rounded-full bg-gradient-to-r from-rose-400 to-amber-300 text-white hover:opacity-90 active:scale-95 transition-all shadow-md ${
            (!inputText.trim() || isThinking) && 'opacity-40 cursor-not-allowed'
          }`}
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}
