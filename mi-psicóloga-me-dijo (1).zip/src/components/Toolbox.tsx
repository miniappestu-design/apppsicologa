import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Flame, ShieldAlert, Sparkles, Smile, RefreshCw, EyeOff, Award, CheckCircle } from 'lucide-react';
import { Language, UserState } from '../types';

interface ToolboxProps {
  language: Language;
  userState: UserState;
  onGainXP: (amount: number) => void;
}

export default function Toolbox({ language, userState, onGainXP }: ToolboxProps) {
  const [fearText, setFearText] = useState('');
  const [isBurning, setIsBurning] = useState(false);
  const [burnedCount, setBurnedCount] = useState(0);

  // Cognitive Reframing Quiz State
  const [quizIndex, setQuizIdx] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  const currentTheme = userState.theme;

  const handleBurn = () => {
    if (!fearText.trim()) return;
    setIsBurning(true);
    setTimeout(() => {
      setIsBurning(false);
      setFearText('');
      setBurnedCount(prev => prev + 1);
      onGainXP(30); // Grant XP for CBT burning fear activity
    }, 2500);
  };

  const cognitiveQuestions = [
    {
      thought: language === 'es' ? '«Si me esfuerzo y le doy suficiente amor, él cambiará por mí.»' : '"If I try hard enough and give him enough love, he will change for me."',
      options: language === 'es' ? [
        'Él me amará si espero pacientemente un año más.',
        'La gente solo cambia cuando acepta que tiene algo que cambiar. Nadie cambia por ti.',
        'Debo cambiar mi actitud para gustarle más.'
      ] : [
        'He will love me if I wait patiently for another year.',
        'People only change when they accept they need to. Nobody changes for you.',
        'I must change my attitude to please him more.'
      ],
      correct: 1,
      reframing: language === 'es'
        ? 'Correcto. Tal como dice la Sesión 15: "Nadie cambia por ti. Creer que tienes el poder de cambiar a quien no quiere cambiar es una fantasía dolorosa". El amor sano empieza por elegirte.'
        : 'Correct. As Session 15 says: "Nobody changes for you. Believing you have the power to change someone who does not want to is a painful fantasy". Healthy love starts by choosing yourself.'
    },
    {
      thought: language === 'es' ? '«Debo perdonarlo y sanar todo de inmediato para poder ser feliz.»' : '"I must forgive him and heal everything immediately in order to be happy."',
      options: language === 'es' ? [
        'No todo se perdona, no todo se sana, y está bien tomar distancia sin perdonar.',
        'El perdón es obligatorio para liberarme.',
        'La rabia siempre es mala y debo reprimirla.'
      ] : [
        'Not everything is forgiven, not everything heals, and it is fine to keep distance without forgiving.',
        'Forgiveness is mandatory to free myself.',
        'Anger is always bad and I must suppress it.'
      ],
      correct: 0,
      reframing: language === 'es'
        ? '¡Excelente! Sesión 2: "No todo se sana, porque hay heridas que simplemente se vuelven parte de quien eres. No te tortures, lo que falta es que dejen de ser abusivos".'
        : 'Excellent! Session 2: "Not everything heals, because some wounds simply become part of who you are. Do not torture yourself, what is needed is for them to stop being abusive".'
    }
  ];

  const handleQuizAnswer = (idx: number) => {
    setSelectedOption(idx);
    setShowExplanation(true);
    if (idx === cognitiveQuestions[quizIndex].correct) {
      setQuizScore(prev => prev + 1);
      onGainXP(40);
    }
  };

  const handleNextQuiz = () => {
    setSelectedOption(null);
    setShowExplanation(false);
    setQuizIdx(prev => (prev + 1) % cognitiveQuestions.length);
  };

  return (
    <div id="toolbox-container" className="max-w-xl mx-auto space-y-6 overflow-y-auto h-[calc(100vh-140px)] pr-1 scrollbar-thin">
      {/* Intro Description */}
      <div>
        <h2 className={`text-2xl font-bold tracking-tight flex items-center gap-2 ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
          <Sparkles className="w-6 h-6 text-rose-400" />
          {language === 'es' ? 'Caja de Herramientas Cognitivas' : 'Cognitive Behavioral Toolbox'}
        </h2>
        <p className="text-xs text-neutral-400">
          {language === 'es' 
            ? 'Ejercicios interactivos basados en terapia cognitivo-conductual.' 
            : 'Interactive exercises based on cognitive-behavioral therapy.'}
        </p>
      </div>

      {/* CBT Tool 1: WRITE & BURN YOUR TOXIC THOUGHTS */}
      <div className={`p-5 rounded-3xl border relative overflow-hidden shadow-sm ${
        currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
      }`}>
        <div className="flex items-center justify-between mb-3">
          <h3 className={`font-semibold tracking-tight text-sm md:text-base flex items-center gap-2 ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
            <Flame className="w-5 h-5 text-coral-400 animate-pulse" />
            {language === 'es' ? 'Quema tus Culpas y Miedos' : 'Burn Your Fear & Guilt'}
          </h3>
          <span className="text-[10px] bg-rose-50 text-rose-500 px-2 py-1 rounded-full font-bold">
            {burnedCount} {language === 'es' ? 'Quemados' : 'Liberated'}
          </span>
        </div>
        <p className="text-xs text-neutral-400 mb-4 leading-relaxed">
          {language === 'es'
            ? 'Escribe ese pensamiento tóxico, culpa o creencia impuesta que hoy decides soltar. Míralo disolverse en el fuego digital y libérate de su peso.'
            : 'Write that toxic thought, guilt, or belief you decide to let go. See it dissolve into digital fire and free yourself from its weight.'}
        </p>

        <AnimatePresence mode="wait">
          {!isBurning ? (
            <motion.div
              key="input"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="space-y-3"
            >
              <textarea
                value={fearText}
                onChange={(e) => setFearText(e.target.value)}
                placeholder={
                  language === 'es'
                    ? 'Ej: "Siento que es mi culpa que me traten mal..."'
                    : 'e.g., "I feel like it is my fault they treat me badly..."'
                }
                className={`w-full p-4 text-xs rounded-2xl border resize-none h-24 focus:outline-none focus:ring-2 focus:ring-rose-300 ${
                  currentTheme === 'dark'
                    ? 'bg-neutral-950 border-neutral-800 text-white'
                    : 'bg-rose-50/10 border-rose-100/40 text-neutral-800'
                }`}
              />
              <button
                id="burn-fear-btn"
                onClick={handleBurn}
                disabled={!fearText.trim()}
                className={`w-full py-3.5 rounded-full text-xs font-semibold tracking-wide bg-gradient-to-r from-orange-400 to-rose-400 text-white shadow-md active:scale-95 transition-all ${
                  !fearText.trim() && 'opacity-50 cursor-not-allowed'
                }`}
              >
                {language === 'es' ? 'Prender fuego y liberar (+30 XP)' : 'Set fire and let go (+30 XP)'}
              </button>
            </motion.div>
          ) : (
            <motion.div
              key="fire"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex flex-col items-center justify-center py-6"
            >
              {/* Custom SVG Flame microinteraction */}
              <motion.div
                animate={{
                  scale: [1, 1.1, 1],
                  rotate: [-3, 3, -3]
                }}
                transition={{ repeat: Infinity, duration: 0.8 }}
                className="w-16 h-16 bg-gradient-to-t from-red-500 via-orange-400 to-yellow-300 rounded-full blur-sm shadow-xl flex items-center justify-center text-white"
              >
                🔥
              </motion.div>
              <p className="text-xs text-orange-400 font-bold tracking-widest mt-4 animate-pulse uppercase">
                {language === 'es' ? 'DISOLVIENDO CULPA...' : 'BURNING AWAY GUILT...'}
              </p>
              <p className="text-[10px] text-neutral-400 italic text-center max-w-xs mt-1">
                {language === 'es' ? '«No es tu culpa. Te estás eligiendo.»' : '"It is not your fault. You are choosing yourself."'}
              </p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* CBT Tool 2: COGNITIVE REFRAMING QUIZ */}
      <div className={`p-5 rounded-3xl border relative shadow-sm ${
        currentTheme === 'dark' ? 'bg-neutral-900/60 border-neutral-850' : 'bg-white border-rose-100/50'
      }`}>
        <div className="flex items-center justify-between mb-3">
          <h3 className={`font-semibold tracking-tight text-sm md:text-base flex items-center gap-2 ${currentTheme === 'dark' ? 'text-white' : 'text-neutral-800'}`}>
            <ShieldAlert className="w-5 h-5 text-rose-400" />
            {language === 'es' ? 'Entrenamiento de Pensamiento Sano' : 'Healthy Thought Training'}
          </h3>
          <span className="text-[10px] bg-amber-50 text-amber-600 px-2.5 py-1 rounded-full font-bold flex items-center gap-1">
            <Award className="w-3.5 h-3.5" />
            +40 XP
          </span>
        </div>
        <p className="text-xs text-neutral-400 mb-4 leading-relaxed">
          {language === 'es'
            ? 'La mente a veces nos miente con ideas culpabilizadoras. Elige la opción que represente una reestructuración cognitiva saludable.'
            : 'The mind sometimes lies with guilt-inducing thoughts. Select the option that represents a healthy cognitive restructuring.'}
        </p>

        {/* Current Quiz Card */}
        <div className={`p-4 rounded-2xl mb-4 border ${
          currentTheme === 'dark' ? 'bg-neutral-950 border-neutral-850' : 'bg-rose-50/10 border-rose-100/30'
        }`}>
          <span className="text-[9px] uppercase tracking-widest font-bold text-rose-400">
            {language === 'es' ? 'PENSAMIENTO LIMITANTE DE HOY:' : 'LIMITING THOUGHT OF TODAY:'}
          </span>
          <p className={`font-semibold text-xs md:text-sm mt-1 leading-snug italic ${currentTheme === 'dark' ? 'text-neutral-200' : 'text-neutral-700'}`}>
            {cognitiveQuestions[quizIndex].thought}
          </p>
        </div>

        {/* Options list */}
        <div className="space-y-2">
          {cognitiveQuestions[quizIndex].options.map((option, idx) => {
            const isCorrect = idx === cognitiveQuestions[quizIndex].correct;
            const isSelected = selectedOption === idx;
            return (
              <button
                key={idx}
                disabled={selectedOption !== null}
                onClick={() => handleQuizAnswer(idx)}
                className={`w-full p-3 rounded-xl border text-left text-xs font-medium leading-relaxed transition-all ${
                  selectedOption !== null
                    ? isCorrect
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                      : isSelected
                        ? 'bg-red-50 border-red-200 text-red-800'
                        : 'opacity-50'
                    : currentTheme === 'dark'
                      ? 'bg-neutral-900 border-neutral-800 text-neutral-300 hover:border-rose-300'
                      : 'bg-white border-rose-100/30 text-neutral-700 hover:border-rose-300'
                }`}
              >
                {option}
              </button>
            );
          })}
        </div>

        {/* Explanation Card */}
        {showExplanation && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`p-4 rounded-2xl mt-4 border flex items-start gap-3 ${
              selectedOption === cognitiveQuestions[quizIndex].correct
                ? 'bg-emerald-50/30 border-emerald-100 text-emerald-800'
                : 'bg-neutral-50/50 border-neutral-200 text-neutral-600'
            }`}
          >
            {selectedOption === cognitiveQuestions[quizIndex].correct ? (
              <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
            ) : (
              <EyeOff className="w-5 h-5 text-neutral-400 shrink-0 mt-0.5" />
            )}
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider mb-1">
                {selectedOption === cognitiveQuestions[quizIndex].correct
                  ? (language === 'es' ? '¡Excelente Reframing!' : 'Excellent Reframing!')
                  : (language === 'es' ? 'Respuesta incorrecta' : 'Incorrect choice')}
              </p>
              <p className="text-xs leading-relaxed text-neutral-400">
                {cognitiveQuestions[quizIndex].reframing}
              </p>
              <button
                onClick={handleNextQuiz}
                className="mt-3 px-3.5 py-1.5 bg-rose-400 text-white rounded-full text-[10px] font-bold hover:bg-rose-500 transition-colors uppercase tracking-wider"
              >
                {language === 'es' ? 'Siguiente Pensamiento' : 'Next Thought'}
              </button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
