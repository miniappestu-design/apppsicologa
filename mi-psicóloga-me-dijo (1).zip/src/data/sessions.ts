import { Session } from '../types';

export const seedSessions: Session[] = [
  {
    id: 1,
    title: 'Necesitas estar harta para empezar a cambiar',
    category: 'crecimiento',
    summary: 'Solo desde el cansancio profundo, ese que aprieta el pecho, nace la decisión de cambiar y dejar el modo supervivencia.',
    quote: 'A veces, para renacer, primero hay que cansarse de sobrevivir.',
    content: 'Lo primero que necesitas para mejorar tu vida es estar harta. Harta de vivir en modo supervivencia, de pensar siempre en función del miedo, de llenarte con lo que no te nutre, de rodearte de personas que solo te drenan la energía, de aguantar lo que ya no tendrías que seguir soportando. Porque solo desde el cansancio profundo, nace la decisión de cambiar, de moverse, de decir: "ya no más". Y ahí empieza todo: cambiar lo que duele, soltar lo que pesa, alejarse de lo que no te representa, empezar, poco a poco, a construirte.',
    reflectionPrompt: '¿Qué cosas o situaciones de tu vida hoy te hacen sentir que estás en "modo supervivencia"?',
    exercise: {
      type: 'write',
      title: 'Escribe tu declaración de "Ya no más"',
      instructions: 'Identifica una sola cosa que estás tolerando hoy y que decides dejar de aguantar a partir de este momento.',
      prompt: 'Decido dejar de aguantar...'
    }
  },
  {
    id: 2,
    title: 'No todo se perdona, no todo se sana',
    category: 'duelo',
    summary: 'La idea de que debes sanar y perdonar para estar bien es otra forma de exigirte. Hay cosas que se entienden y se sueltan, pero no se perdonan.',
    quote: 'No te tortures. No te falta perdonar para ser feliz; lo que falta es que los demás dejen de ser abusivos.',
    content: 'No tienes que hacer las paces con todo para seguir adelante. No todo se perdona, porque hay cosas que no tienen excusa. No todo se sana, porque hay heridas que simplemente se vuelven parte de quien eres. Esa idea de que "debes sanar y perdonar para estar bien" es solo otra forma de exigirte más. No te tortures. No te falta perdonar para ser feliz; lo que falta es que los demás dejen de ser unos abusivos emocionales. Así que no estás loca por pensar que hay cosas que se entienden, se sueltan... pero no se perdonan. No odias a nadie, pero tampoco merecen tu perdón, y menos si nunca mostraron arrepentimiento.',
    reflectionPrompt: '¿Te has sentido obligada a perdonar a alguien solo para complacer expectativas de otros?',
    exercise: {
      type: 'choice',
      title: 'Elige tu paso de liberación',
      instructions: 'Hoy no tienes que perdonar. Elige cuál de estas acciones te dará más paz hoy:',
      choices: [
        'Aceptar que lo que pasó estuvo mal y no tiene justificación',
        'Establecer distancia física o digital definitiva',
        'Dejar de buscar explicaciones o un arrepentimiento que nunca llegará'
      ]
    }
  },
  {
    id: 3,
    title: 'No tienes que soltar si no estás lista',
    category: 'apego',
    summary: 'El corazón no funciona con comandos ni relojes. Aferrarse un poco también es parte de procesar y aprender.',
    quote: 'Soltar no es una obligación, es una decisión que tomas cuando estás lista, no cuando te lo exigen.',
    content: 'Todo el mundo habla de soltar, dejar ir, cortar lazos. Pero ¿sabes qué? No todo se suelta de inmediato. Aferrarse un poco también es entender, procesar, aprender. No significa que estés estancada, solo que estás tomando el tiempo que necesitas. Algunas heridas no sanan de la noche a la mañana; tampoco significa que no sepas o no quieras soltar, es solo que tu corazón no funciona con comandos ni relojes. Y está bien. No te fuerces a soltar solo porque todos dicen que deberías hacerlo.',
    reflectionPrompt: '¿Qué herida sientes que te exigen soltar antes de estar verdaderamente lista?',
    exercise: {
      type: 'breathe',
      title: 'Respiración para darte tregua',
      instructions: 'Realiza 3 ciclos de respiración profunda recordando que tu proceso tiene su propio ritmo natural.'
    }
  },
  {
    id: 4,
    title: 'Deja de perseguir a la mejor versión de ti',
    category: 'autoestima',
    summary: 'Ya te moldeaste mil veces para encajar. Tu versión rota, triste o agotada también merece amor y compasión hoy.',
    quote: 'A veces lo único que necesitas es dejar de exigirte tanto y empezar a abrazarte tal como estás.',
    content: 'No necesitas cambiar. Ya te moldeaste mil veces para encajar, para caer bien, para que no se fueran. Te callaste, te tragaste cosas que no merecías, te hiciste fuerte cuando solo querías llorar. Y ahora te exigen que seas "tu mejor versión", como si esta no valiera. ¿Sabes qué? Esta versión también merece amor. No siempre tienes que estar bien o persiguiendo a la mejor versión de ti. A veces lo único que necesitas es dejar de exigirte tanto y empezar a abrazarte tal como estás: rota, triste, agotada. Porque así, con todo y tus grietas, eres suficiente.',
    reflectionPrompt: '¿Cómo se siente abrazar tu versión cansada de hoy en lugar de juzgarla?',
    exercise: {
      type: 'write',
      title: 'Carta a mi versión actual',
      instructions: 'Escribe una pequeña nota de compasión diciéndote que está bien no ser perfecta hoy.',
      prompt: 'Hoy me permito...'
    }
  },
  {
    id: 5,
    title: 'El fracaso no es el enemigo',
    category: 'crecimiento',
    summary: 'No sabemos descansar sin culpa por miedo a no ser suficientes si no estamos produciendo. El descanso también cuenta.',
    quote: 'Témele a convertir tu vida en una carrera que nunca te deja respirar.',
    content: 'Nos exigimos tanto que se nos olvida vivir. No sabemos descansar sin culpa. No sabemos parar sin sentir que estamos perdiendo el tiempo. No es ambición, es miedo: miedo a no ser suficientes si no estamos produciendo, demostrando, avanzando. Miedo a no estar "a la altura" de un mundo que solo aplaude lo visible. Pero lo invisible también cuenta. Respirar o sobrevivir a ti misma también cuenta. No necesitas otra lista de cosas por hacer, necesitas dejar de exigirte tanto.',
    reflectionPrompt: '¿Cuándo fue la última vez que descansaste plenamente sin sentir culpa por "no hacer nada"?',
    exercise: {
      type: 'choice',
      title: 'Elige tu pausa consciente para hoy',
      instructions: 'Selecciona una actividad de desaceleración que realizarás hoy sin remordimientos:',
      choices: [
        'Desconectarme de redes sociales por 2 horas',
        'Tomar una siesta o acostarme temprano',
        'Disfrutar de una bebida caliente mirando al vacío por 15 minutos'
      ]
    }
  },
  {
    id: 6,
    title: 'No es que estén heridos, es que disfrutan lastimar',
    category: 'relaciones',
    summary: 'Hay personas que no están rotas, sino que disfrutan hacer daño. Tu distancia es su único remedio.',
    quote: 'Hay gente que no necesita ayuda: necesita distancia. Y punto.',
    content: 'No todo el mundo merece una segunda oportunidad, ni tus explicaciones, ni tu comprensión. Hay personas que no están rotas: están podridas. No es trauma, es maldad. No es que estén heridas, es que disfrutan hacer daño. Y tú no estás en este mundo para ser el tapete emocional de nadie. Deja de justificar lo que no tiene justificación. Deja de aguantar por miedo a parecer insensible. Aprende a irte. Aprende a soltar.',
    reflectionPrompt: '¿A quién has estado justificando pensando que "cambiará" si le das más amor?',
    exercise: {
      type: 'write',
      title: 'Dibuja tu límite mental',
      instructions: 'Establece de manera escrita la línea que esa persona tóxica no volverá a cruzar.',
      prompt: 'A partir de hoy, no permitiré que...'
    }
  },
  {
    id: 7,
    title: 'No eres el saco de boxeo de nadie',
    category: 'limites',
    summary: 'A veces ser buena es ser tonta. Poner límites y cortar lo que te destruye no te hace la villana de la historia.',
    quote: 'No eres la villana; solo eres quien decidió no ser el saco de boxeo de nadie.',
    content: 'Deja de hacerte la buena cuando la gente tóxica te destruye. A veces, ser buena es ser idiota. No tienes que aguantar ni un segundo más a quienes te tratan mal solo para mantener la paz o evitar ser la mala. Ser buena no significa permitir que te pisoteen. A veces, no ponerle límite a tu bondad solo alimenta a los que viven de tu buena voluntad. PON LÍMITES, corta lo que te destruye y deja de disculparte por hacerlo.',
    reflectionPrompt: '¿Qué límites necesitas poner hoy para proteger tu paz mental?',
    exercise: {
      type: 'choice',
      title: 'Elige un límite para aplicar',
      instructions: 'Elige una acción para reafirmar tu valor propio:',
      choices: [
        'Decir "No" sin dar explicaciones ni disculpas',
        'Dejar de responder mensajes fuera de horas cómodas',
        'Retirarme de una conversación cuando me falten al respeto'
      ]
    }
  },
  {
    id: 8,
    title: 'Puedes con todo, pero no al mismo tiempo',
    category: 'ansiedad',
    summary: 'Cuando sientas que la vida te supera, párate. No intentes cargar el mundo entero en un solo día.',
    quote: 'Hazlo simple: un día a la vez. Una decisión a la vez. Una tarea a la vez.',
    content: 'Cuando sientas que todo te supera, párate. Respira. No es que no puedas con la vida, es que estás intentando cargarla entera de una sola vez. Y no se puede. Así que hazlo simple: un día a la vez. Una decisión a la vez. Una tarea a la vez. No te exijas resolver tu existencia entera hoy. Porque todo se desborda cuando olvidas que incluso la tormenta más fuerte, también pasa...',
    reflectionPrompt: '¿Qué carga de mañana puedes soltar hoy para aliviar tu mente?',
    exercise: {
      type: 'breathe',
      title: 'Pausa de descompresión',
      instructions: 'Haz clic en el círculo y realiza 5 respiraciones profundas al ritmo indicado.'
    }
  }
];

// Dynamically generate remaining sessions up to 110 so we have an infinite library
const actualOcrTitles = [
  'Hazlo, porque igual te van a criticar',
  'No necesitas quererte más. Necesitas que dejen de romperte',
  'Colapsas porque estás harta, no porque estés loca',
  'No te rodees de gente mediocre',
  'La muerte es un puñal que se queda clavado para siempre',
  'No te abandones porque alguien más lo hizo',
  'Nadie va a cambiar porque tú se lo pidas',
  '¿Cómo dejo de sentirme tan triste o vacía?',
  '¿Por qué me autosaboteo todo el tiempo?',
  '¿Cómo sé si debo soltar o seguir luchando?',
  '¿Qué hago si aún lo amo pero me hace daño?',
  'Alguien más estará feliz de que te hayan perdido',
  'No te permitas depender de nadie',
  'No necesitas poder con todo',
  'Sanar no significa no volver a caer',
  'No es indigestión, es ansiedad',
  'La vida no tiene que ser una lucha constante',
  'Las palabras bonitas se las lleva el viento',
  'Al carajo los casi algo',
  'Compararte solo te enferma',
  'Eres valiente para todo menos para decir que no puedes más',
  'El amor propio no siempre es amarte',
  'Te estás eligiendo. Por eso todo se está derrumbando',
  'A la mierda los que te drenan',
  'No es falta de tiempo, es que no le interesas',
  'Ser feliz es tu mayor acto de venganza',
  'No vivas para ser bonita para otros',
  'Deja de correr por un reloj que no es tuyo',
  'No tienes que estar disponible todo el tiempo para todos',
  'Lo que parece poco para ti, es mucho para alguien más',
  'La lealtad no es amor',
  'Que no te importe lo que los demás digan',
  'Más apoyo, menos veneno entre mujeres',
  'No arregles a quien después te va a romper',
  'No te descuides por cuidar a los demás',
  'Tus hijos necesitan padres felices',
  'Ser mamá soltera no te resta valor',
  'Lloras, pero no porque quieras que vuelva',
  'No te pongas el traje de víctima',
  'Tu mente puede ser tu enemiga',
  'El ego también se disfraza de amor',
  'Hay quienes nunca debieron defraudarte',
  'No esperes a que sea el último día',
  'A ti no te mata nada, todo te transforma',
  'No le temas a los cambios',
  'No seas tan cruel contigo',
  '¿Cómo dejo de depender emocionalmente?',
  '¿Qué hago si todo me da ansiedad?',
  '¿Qué necesito para sentirme mejor con mi vida?',
  '¿Qué hago con todo este enojo guardado?',
  'Ser buena persona no es garantía de nada',
  'Tu yo del futuro te lo va a agradecer',
  'Decepciónalos a todos',
  'Tú también sabes hacer daño, pero no lo haces',
  'Deja de creer en palabritas bonitas',
  'En la vida todo se paga',
  'Mejor estar sola pero en paz',
  'No naciste para entregar nada a medias',
  'Te cansaste de la gente hipócrita',
  'No tires la toalla antes de ver cómo mejora',
  'Hay alguien que nunca te va a dejar caer',
  'No estás fallando, solo olvidaste quién eres',
  'No es tu tarea salvar a nadie',
  'Si tienes que pedirlo, ahí está el problema',
  'Deja de vaciarte intentando arreglar lo roto',
  'Solo quieres a alguien que decida ser tu hogar',
  'No estás mal por esperar respeto',
  'Si se fue, es porque ya no quería quedarse',
  'El tiempo no siempre lo cura todo, pero sanarás',
  'Todos están esperando verte fallar, así que brilla',
  'Quiéreme bonito',
  'No eres una mala persona por haber fallado',
  'Decepciónate tantas veces hasta que el amor se apague',
  'Dañar a otro no te sana, solo te pudre',
  'El brillo no era de ellos, era tuyo',
  'Tu paz ya no es negociable',
  'Ten paciencia. Nada se construye de la noche a la mañana',
  'No le cuentes tus planes a nadie. Solo a Dios',
  'La verdadera riqueza no es el dinero',
  'Hoy todos quieren compañía, pero no compromiso',
  'Solo quieres a alguien que tenga las cosas claras',
  'No le dejes todo a Dios, haz tu parte',
  'Si te ve llorar y no hace nada, ahí tienes la respuesta',
  'Ya no estás para amistades falsas',
  'En la soledad es cuando realmente te conoces',
  'El silencio no siempre es calma, es un aviso',
  'Nadie se muere por empezar de cero',
  'Estás en ese momento donde solo quieres paz',
  'No es tu voz adulta, es tu niña interior',
  'La vida se te va mientras tú dudas',
  'No le temas al amor bonito',
  'No necesitas una disculpa para cerrar la herida',
  'No todo se soluciona con un perdón',
  'Si vas a perdonar, hazlo de verdad',
  'No tienes que saber manejar todo siempre',
  'No son celos, es falta de certezas',
  'Solo tienes que abrir tu cajita de ojalá',
  'Ojalá el cielo tuviera horario de visita',
  'No te conformes con la vida que heredaste',
  'No se construye sobre los escombros de alguien más',
  'No olvides todo lo que has logrado',
  'No seas de las que jode más el mundo',
  'Mereces a alguien que también te cuide',
  'A veces es mejor tener paz que tener la razón',
  'No te obsesiones con encontrar tu gran propósito',
  'No todo debería tener un porqué',
  'No tienes que estar feliz todos los días',
  'No escuches cuando es el miedo quien habla',
  'Pensar en el futuro solo te causa ansiedad',
  'No es orgullo, solo sabes lo que quieres',
  'Y un día te toca entender cómo se siente el duelo',
  'Dejas de necesitar a alguien cuando te tienes a ti',
  'Preocúpate ahora por estar en paz contigo y con Dios'
];

export const allSessions: Session[] = [...seedSessions];

const categories: Session['category'][] = [
  'ansiedad',
  'autoestima',
  'limites',
  'apego',
  'relaciones',
  'duelo',
  'crecimiento'
];

// Hydrate up to exactly 110 sessions programmatically using titles from the book
actualOcrTitles.forEach((title, index) => {
  const id = index + 9; // Seed has 1 to 8
  if (id <= 110) {
    const category = categories[index % categories.length];
    allSessions.push({
      id,
      title,
      category,
      summary: `Exploración interactiva de la Sesión #${id} del best-seller. Aprende a priorizarte, poner límites y sanar sin culpas.`,
      quote: `Sesión #${id}: Sigue adelante con tu propio ritmo y elige tu paz sobre las expectativas ajenas.`,
      content: `Esta es la sesión #${id} titulada "${title}". Te invita a reflexionar profundamente sobre las decisiones que tomas cada día, dejando atrás el papel de víctima y tomando la responsabilidad de tu propia felicidad. Recuerda que no necesitas la aprobación de nadie para ser libre.`,
      reflectionPrompt: `¿Cómo resuena la sesión "${title}" en tus relaciones personales actuales?`,
      exercise: {
        type: 'write',
        title: `Práctica de la Sesión #${id}`,
        instructions: 'Escribe un breve compromiso contigo misma basado en esta sesión:',
        prompt: 'Me comprometo a...'
      }
    });
  }
});
