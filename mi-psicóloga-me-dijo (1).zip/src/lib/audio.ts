// Web Audio API Ambient Synthesizer for high-fidelity offline audio soundscapes
class ZenAudioSynthesizer {
  private ctx: AudioContext | null = null;
  private synthInterval: any = null;
  private synthNodes: OscillatorNode[] = [];
  private rainGain: GainNode | null = null;
  private oceanGain: GainNode | null = null;
  private synthGain: GainNode | null = null;
  private masterGain: GainNode | null = null;

  init() {
    if (this.ctx) return;
    try {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.8, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
    } catch (e) {
      console.error('Failed to initialize AudioContext:', e);
    }
  }

  resumeContext() {
    this.init();
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(e => console.error('Error resuming audio:', e));
    }
  }

  // Real-time volume control
  setVolume(type: 'rain' | 'ocean' | 'synth', volume: number) {
    this.resumeContext();
    if (!this.ctx) return;
    const gainNode = type === 'rain' ? this.rainGain : type === 'ocean' ? this.oceanGain : this.synthGain;
    if (gainNode) {
      gainNode.gain.linearRampToValueAtTime(volume, this.ctx.currentTime + 0.1);
    }
  }

  // Smooth global fade-out and stop
  fadeOutAndStop(durationSeconds: number = 3) {
    if (!this.ctx) return;
    const now = this.ctx.currentTime;
    
    if (this.rainGain) {
      this.rainGain.gain.setValueAtTime(this.rainGain.gain.value, now);
      this.rainGain.gain.linearRampToValueAtTime(0, now + durationSeconds);
    }
    if (this.oceanGain) {
      this.oceanGain.gain.setValueAtTime(this.oceanGain.gain.value, now);
      this.oceanGain.gain.linearRampToValueAtTime(0, now + durationSeconds);
    }
    if (this.synthGain) {
      this.synthGain.gain.setValueAtTime(this.synthGain.gain.value, now);
      this.synthGain.gain.linearRampToValueAtTime(0, now + durationSeconds);
    }

    setTimeout(() => {
      this.stopAll();
    }, durationSeconds * 1000);
  }

  // Generate real rain noise on the fly
  playRain(volume: number = 0.15) {
    this.resumeContext();
    if (!this.ctx) return;
    this.stopRain();

    // Create low-pass filtered noise
    const bufferSize = 2 * this.ctx.sampleRate;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      output[i] = Math.random() * 2 - 1;
    }

    const whiteNoise = this.ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    whiteNoise.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(1000, this.ctx.currentTime);

    this.rainGain = this.ctx.createGain();
    this.rainGain.gain.setValueAtTime(0, this.ctx.currentTime);
    this.rainGain.gain.linearRampToValueAtTime(volume, this.ctx.currentTime + 1.5); // Soft fade-in

    whiteNoise.connect(filter);
    filter.connect(this.rainGain);
    this.rainGain.connect(this.masterGain!);

    whiteNoise.start();
    (this as any).rainSource = whiteNoise;
  }

  stopRain() {
    if ((this as any).rainSource) {
      try {
        (this as any).rainSource.stop();
      } catch (e) {}
      (this as any).rainSource = null;
    }
  }

  // Synthesize realistic slow ocean waves
  playOcean(volume: number = 0.25) {
    this.resumeContext();
    if (!this.ctx) return;
    this.stopOcean();

    // Noise buffer
    const bufferSize = 2 * this.ctx.sampleRate;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);
    let lastOut = 0.0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      // Pink filter approximation
      output[i] = (lastOut * 0.99 + white * 0.01) / 2;
      lastOut = output[i];
    }

    const pinkNoise = this.ctx.createBufferSource();
    pinkNoise.buffer = noiseBuffer;
    pinkNoise.loop = true;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(300, this.ctx.currentTime);

    // LFO to modulate filter frequency slowly (wave cycle of 6 seconds)
    const lfo = this.ctx.createOscillator();
    lfo.frequency.setValueAtTime(0.12, this.ctx.currentTime); // 0.12 Hz

    const lfoGain = this.ctx.createGain();
    lfoGain.gain.setValueAtTime(220, this.ctx.currentTime); // Modulate cut-off by 220Hz

    this.oceanGain = this.ctx.createGain();
    this.oceanGain.gain.setValueAtTime(0, this.ctx.currentTime);
    this.oceanGain.gain.linearRampToValueAtTime(volume, this.ctx.currentTime + 2.0); // Soft fade-in

    lfo.connect(lfoGain);
    lfoGain.connect(filter.frequency);
    pinkNoise.connect(filter);
    filter.connect(this.oceanGain);
    this.oceanGain.connect(this.masterGain!);

    lfo.start();
    pinkNoise.start();
    (this as any).oceanSource = pinkNoise;
    (this as any).oceanLfo = lfo;
  }

  stopOcean() {
    if ((this as any).oceanSource) {
      try {
        (this as any).oceanSource.stop();
        (this as any).oceanLfo.stop();
      } catch (e) {}
      (this as any).oceanSource = null;
      (this as any).oceanLfo = null;
    }
  }

  // Synthesize peaceful progressive drone pads
  playSynth(volume: number = 0.12) {
    this.resumeContext();
    if (!this.ctx) return;
    this.stopSynth();

    this.synthGain = this.ctx.createGain();
    this.synthGain.gain.setValueAtTime(volume, this.ctx.currentTime);
    this.synthGain.connect(this.masterGain!);

    const chords = [
      [130.81, 164.81, 196.0, 246.94], // Cmaj7 (C3, E3, G3, B3)
      [146.83, 174.61, 220.0, 261.63], // Dm7 (D3, F3, A3, C4)
      [110.0, 130.81, 164.81, 196.0],  // Am7 (A2, C3, E3, G3)
      [116.54, 146.83, 174.61, 220.0]  // Bbmaj7 (Bb2, D3, F3, A3)
    ];

    let chordIdx = 0;

    const playNextChord = () => {
      if (!this.ctx || !this.synthGain) return;
      const frequencies = chords[chordIdx];
      chordIdx = (chordIdx + 1) % chords.length;

      // Stop previous oscs safely
      this.synthNodes.forEach(osc => {
        try {
          osc.stop();
        } catch (e) {}
      });
      this.synthNodes = [];

      frequencies.forEach(freq => {
        if (!this.ctx || !this.synthGain) return;
        const osc = this.ctx.createOscillator();
        const oscGain = this.ctx.createGain();

        // Slow attack
        oscGain.gain.setValueAtTime(0, this.ctx.currentTime);
        oscGain.gain.linearRampToValueAtTime(0.04, this.ctx.currentTime + 2.5);
        // Slow release before chord switch
        oscGain.gain.setValueAtTime(0.04, this.ctx.currentTime + 6.0);
        oscGain.gain.linearRampToValueAtTime(0, this.ctx.currentTime + 8.0);

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

        // Add a gentle detune to make it richer
        osc.detune.setValueAtTime(Math.random() * 10 - 5, this.ctx.currentTime);

        osc.connect(oscGain);
        oscGain.connect(this.synthGain);
        osc.start();
        this.synthNodes.push(osc);
      });
    };

    playNextChord();
    this.synthInterval = setInterval(playNextChord, 8000);
  }

  stopSynth() {
    if (this.synthInterval) {
      clearInterval(this.synthInterval);
      this.synthInterval = null;
    }
    this.synthNodes.forEach(osc => {
      try {
        osc.stop();
      } catch (e) {}
    });
    this.synthNodes = [];
    if (this.synthGain) {
      this.synthGain.disconnect();
      this.synthGain = null;
    }
  }

  // Play a soft guided chime
  playBell(freq: number = 523.25) { // default High C
    this.resumeContext();
    if (!this.ctx) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

    gain.gain.setValueAtTime(0.18, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 2.5); // long resonance decay

    osc.connect(gain);
    gain.connect(this.masterGain!);

    osc.start();
    osc.stop(this.ctx.currentTime + 3.0);
  }

  stopAll() {
    this.stopRain();
    this.stopOcean();
    this.stopSynth();
  }
}

export const audioSynth = new ZenAudioSynthesizer();
