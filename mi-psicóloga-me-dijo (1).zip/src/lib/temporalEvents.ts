import { Language } from '../types';

export interface SpecialEvent {
  id: string;
  title: string;
  subtitle: string;
  bgGradient: string;
  badge: string;
  icon: string;
  cbtPrompt: string;
}

/**
 * Premium Temporal Engine to detect and deliver themed exercises, events,
 * and aesthetic banners according to the user's exact current day & special calendar dates.
 */
export function getTemporalEvent(language: Language, dateStr?: string): SpecialEvent | null {
  const targetDate = dateStr ? new Date(dateStr) : new Date();
  const dayOfWeek = targetDate.getDay(); // 0: Sunday, 1: Monday, etc.
  const month = targetDate.getMonth(); // 0: Jan, 11: Dec
  const dayOfMonth = targetDate.getDate();

  // 1. CALENDAR SPECIAL DATES (Highest Priority)
  
  // Women's Day (March 8)
  if (month === 2 && dayOfMonth === 8) {
    return {
      id: 'womens_day',
      title: language === 'es' ? 'Día de la Mujer: Tu Poder no se Negocia' : 'Womens Day: Your Power is Non-Negotiable',
      subtitle: language === 'es' ? 'Hoy celebramos tu fuerza de haber salido adelante sola.' : 'Today we celebrate your strength to move forward alone.',
      bgGradient: 'from-purple-500 via-pink-500 to-rose-400',
      badge: 'Special Event ♀',
      icon: '💜',
      cbtPrompt: language === 'es' 
        ? 'Escribe 3 cosas que admiras de ti hoy y que nadie te regaló.' 
        : 'Write 3 things you admire about yourself today that no one gave you.'
    };
  }

  // Christmas (Dec 24 - 25)
  if (month === 11 && (dayOfMonth === 24 || dayOfMonth === 25)) {
    return {
      id: 'christmas',
      title: language === 'es' ? 'Navidad: Sanar sin Culpa Familiar' : 'Christmas: Healing without Family Guilt',
      subtitle: language === 'es' ? 'Aprende a proteger tu paz incluso en las reuniones familiares más difíciles.' : 'Learn to protect your peace even during the hardest family gatherings.',
      bgGradient: 'from-emerald-600 via-teal-500 to-red-500',
      badge: 'Navidad 🎄',
      icon: '🎁',
      cbtPrompt: language === 'es'
        ? 'Declara tu límite amoroso para estas fiestas. ¿A qué temas o comentarios dirás "no hoy"?'
        : 'Declare your loving boundary for these holidays. What topics or comments will you say "not today" to?'
    };
  }

  // New Year (Dec 31 - Jan 1)
  if ((month === 11 && dayOfMonth === 31) || (month === 0 && dayOfMonth === 1)) {
    return {
      id: 'new_year',
      title: language === 'es' ? 'Año Nuevo: Tu Cajita de Ojalá Abierta' : 'New Year: Opening Your Box of Hopes',
      subtitle: language === 'es' ? 'No lleves a tu nuevo año el peso de quienes te hicieron daño.' : 'Do not carry the weight of those who hurt you into your new year.',
      bgGradient: 'from-amber-400 via-rose-500 to-indigo-600',
      badge: 'New Year ✨',
      icon: '🎆',
      cbtPrompt: language === 'es'
        ? '¿Quién o qué situación decides dejar definitivamente en el pasado hoy?'
        : 'Who or what situation do you decide to leave definitively in the past today?'
    };
  }

  // 2. DAY-OF-THE-WEEK DYNAMIC EVENTS

  // Monday (Lunes) - Reinicio y Enfoque en Límites
  if (dayOfWeek === 1) {
    return {
      id: 'monday_focus',
      title: language === 'es' ? 'Lunes de Enfoque: Tu Paz no es Negociable' : 'Focus Monday: Your Peace is Non-Negotiable',
      subtitle: language === 'es' ? 'Inicia la semana sin el peso de complacer a todos.' : 'Start the week without the weight of pleasing everyone.',
      bgGradient: 'from-indigo-600 via-blue-500 to-teal-400',
      badge: 'Lunes de Límites',
      icon: '🛡️',
      cbtPrompt: language === 'es'
        ? '¿Qué límite preventivo establecerás esta semana en tu trabajo o relaciones?'
        : 'What preventive boundary will you set this week in your work or relationships?'
    };
  }

  // Tuesday (Martes) - Diálogo con tu Niña Interior
  if (dayOfWeek === 2) {
    return {
      id: 'tuesday_child',
      title: language === 'es' ? 'Martes de Abrazo: Tu Niña Interior' : 'Comfort Tuesday: Your Inner Child',
      subtitle: language === 'es' ? 'Hoy curamos esa vocecita que te dice que no eres suficiente.' : 'Today we heal that tiny voice that tells you you are not enough.',
      bgGradient: 'from-rose-400 via-amber-300 to-pink-400',
      badge: 'Niña Interior 🧸',
      icon: '🌸',
      cbtPrompt: language === 'es'
        ? '¿Qué le dirías hoy a tu niña de 8 años para hacerla sentir segura?'
        : 'What would you say today to your 8-year-old self to make her feel safe?'
    };
  }

  // Friday (Viernes) - Al Carajo los Casi Algo / Liberación
  if (dayOfWeek === 5) {
    return {
      id: 'friday_release',
      title: language === 'es' ? 'Viernes de Al Carajo los Casi Algo' : 'Release Friday: Goodbye to "Almost-Somethings"',
      subtitle: language === 'es' ? 'Valorarte significa no mendigar atención el fin de semana.' : 'Valuing yourself means not begging for attention on the weekend.',
      bgGradient: 'from-red-500 via-rose-400 to-amber-400',
      badge: 'Viernes de Poder 🔥',
      icon: '⚡',
      cbtPrompt: language === 'es'
        ? 'Si te escribe esa persona que solo te busca los fines de semana, ¿cómo le responderás?'
        : 'If that person who only seeks you on weekends text you, how will you reply?'
    };
  }

  // Weekend (Sábado & Domingo) - Autocuidado Radical y Recarga
  if (dayOfWeek === 0 || dayOfWeek === 6) {
    return {
      id: 'weekend_recharge',
      title: language === 'es' ? 'Fin de Semana de Autocuidado Radical' : 'Weekend of Radical Self-Care',
      subtitle: language === 'es' ? 'Desconéctate del ruido del mundo. El descanso también cuenta.' : 'Disconnect from the world\'s noise. Rest also counts.',
      bgGradient: 'from-teal-400 via-emerald-500 to-indigo-500',
      badge: 'Autocuidado 🕊️',
      icon: '☕',
      cbtPrompt: language === 'es'
        ? 'Describe tu plan de hoy para darte un abrazo a ti misma sin hacer nada productivo.'
        : 'Describe your plan today to hug yourself without doing anything productive.'
    };
  }

  // Thursday / Wednesday Default (Fallback)
  return {
    id: 'midweek_reflection',
    title: language === 'es' ? 'Mitad de Semana: Tu Propósito Simple' : 'Midweek Reflection: Your Simple Purpose',
    subtitle: language === 'es' ? 'No te obsesiones con el futuro. Hoy respirar es suficiente.' : 'Do not obsess over the future. Today breathing is enough.',
    bgGradient: 'from-rose-400 via-amber-300 to-teal-400',
    badge: 'Paz Interior ✨',
    icon: '🧘‍♀️',
    cbtPrompt: language === 'es'
      ? '¿Qué pequeña cosa de hoy te hizo sentir paz en medio de la rutina?'
      : 'What little thing today made you feel peace in the middle of the routine?'
  };
}
