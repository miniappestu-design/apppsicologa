export type Language = 'es' | 'en' | 'pt' | 'it' | 'fr' | 'de' | 'nl' | 'ca';

export type Mood =
  | 'ansiosa'
  | 'triste'
  | 'con_miedo'
  | 'sin_energia'
  | 'con_culpa'
  | 'enojada'
  | 'con_ansiedad'
  | 'corazon_roto'
  | 'necesito_paz'
  | 'necesito_ayuda'
  | 'quiero_crecer'
  | 'quiero_sanar';

export interface ChatMessage {
  id: string;
  sender: 'user' | 'therapist' | 'system';
  text: string;
  timestamp: string;
}

export interface JournalEntry {
  id: string;
  date: string; // YYYY-MM-DD
  mood: Mood;
  note: string;
  accomplishment: string;
  gratitude: string;
  lesson: string;
  goals: string;
}

export interface Medal {
  id: string;
  titleKey: string;
  descriptionKey: string;
  icon: string;
  unlockedAt?: string;
  xpValue: number;
}

export interface UserState {
  xp: number;
  level: number;
  streak: number;
  lastActiveDate?: string;
  moodHistory: { [date: string]: Mood };
  unlockedMedals: string[]; // medal IDs
  completedDailyTasks: string[]; // task IDs for today, e.g., 'breathing', 'journal', 'game', 'session'
  weeklyXP: number[]; // XP per day Mon-Sun
  soundEnabled: boolean;
  theme: 'light' | 'dark';
  name?: string;
  startDate?: string;
  daysAcompanamiento?: number;
  totalWellnessMinutes?: number;
  activitiesCount?: number;
}

export interface Session {
  id: number;
  title: string;
  category: 'ansiedad' | 'autoestima' | 'limites' | 'apego' | 'relaciones' | 'duelo' | 'crecimiento';
  summary: string;
  content: string;
  quote: string;
  reflectionPrompt: string;
  exercise: {
    type: 'write' | 'swipe' | 'choice' | 'breathe';
    title: string;
    instructions: string;
    prompt?: string;
    choices?: string[];
  };
}

export interface DailyQuest {
  id: string;
  titleKey: string;
  rewardXP: number;
  completed: boolean;
}

export interface QuizQuestion {
  question: string;
  options: string[];
  reframing: string;
}
